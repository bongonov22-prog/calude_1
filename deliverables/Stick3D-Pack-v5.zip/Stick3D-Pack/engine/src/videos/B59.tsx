// B-59 (Oct 1962) — 15 scenes, 9:16 720x1280 30fps, 58.58 s. Patterns reused from NvidiaV4 (Cam spline, FaceGroup/hand, whip/zoom/flash).
import React from "react";
import { AbsoluteFill, Sequence, useCurrentFrame, Easing, Audio, staticFile } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import * as THREE from "three";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Look } from "../style/puppet";
import { Desk, Calendar, Grade, seg, lerp, clamp, V3 } from "../style/kit";
import { Glow, Shaft, Shelf, Dust, Cabinet } from "../style/props";
import { Cam, Key, camAt, FaceGroup, hand, Globe } from "../style/extra";
import { Puppet3D as P3, FogSet, Ring, HullRoom, Bulkhead, HC, HR, FW, Sub, Destroyer, DepthCharge, Torpedo, Gauge, Thermo, Valve, ShipBell, Sea, SurfaceBelow, SkyDome, Cloud, Mushroom, PhoneBase, Handset } from "../style/navy";
import { Captions } from "../Main";

const FPS = 30, LEAD = 6, TAIL = 8, WALK = 3.4;
type Ctx = { t: number; f: number };
type Trans = "ghost" | "zoom" | "flash" | "whip";

/* ---------- cast (same look in every scene) ---------- */
const capt: Look = { skin: "#f1d0b0", body: "#1d2a5c", outfit: "suit", tie: "#0b0d1a", shirt: "#f4f4f4", hair: "short", hairColor: "#2a1a12", hat: "#141a33", shoe: "#0b0d1a" };
const arkh: Look = { skin: "#f7d9bd", body: "#2f6fd8", outfit: "blazer", shirt: "#e8eef8", hair: "swept", hairColor: "#6a3a1a", badge: "#ffc23a", shoe: "#1b1b2a" };
const polit: Look = { skin: "#f3d2b4", body: "#3a2f5a", outfit: "suit", tie: "#d2202e", shirt: "#f4f4f4", hair: "grey", glasses: true, hat: "#2a2244", shoe: "#0b0d1a" };
const sailors: Look[] = [
  { skin: "#fbe3c8", body: "#3f8bd8", outfit: "hoodie", hair: "short", hairColor: "#222", shoe: "#1b1b2a" },
  { skin: "#e0b48c", body: "#2fa7c8", outfit: "shirt", hair: "swept", hairColor: "#3b2a1a", shoe: "#1b1b2a" },
  { skin: "#f6d6bd", body: "#4a6fd0", outfit: "hoodie", hair: "short", hairColor: "#5a3420", glasses: true, shoe: "#1b1b2a" },
  { skin: "#c98e62", body: "#2b8fb0", outfit: "shirt", hair: "short", hairColor: "#111", shoe: "#1b1b2a" },
];
const usN: Look[] = [
  { skin: "#fbe3c8", body: "#f4f6fb", outfit: "shirt", hair: "short", hairColor: "#3b2a1a", hat: "#ffffff", shoe: "#1b1b2a" },
  { skin: "#a86b45", body: "#eef2fa", outfit: "shirt", hair: "short", hairColor: "#111", hat: "#ffffff", shoe: "#1b1b2a" },
  { skin: "#f1c9a5", body: "#f4f6fb", outfit: "shirt", hair: "swept", hairColor: "#c47a2a", hat: "#ffffff", shoe: "#1b1b2a" },
];
const usOff: Look = { skin: "#f6d6bd", body: "#c9a86a", outfit: "suit", tie: "#1b1b2a", shirt: "#f4efe0", hair: "short", hairColor: "#5a3420", hat: "#f4f4f4", shoe: "#2a1a12" };
const suOff: Look = { skin: "#f1d0b0", body: "#1d2a5c", outfit: "suit", tie: "#0b0d1a", shirt: "#f4f4f4", hair: "grey", hat: "#141a33", shoe: "#0b0d1a" };

/* ---------- scene wrapper (ghost / zoom / flash / whip) ---------- */
const Scene: React.FC<{ start: number; end: number; first?: boolean; trans?: Trans; bg: string; children: (c: Ctx) => React.ReactNode }> = ({ start, end, first, trans = "ghost", bg, children }) => {
  const from = Math.round(start * FPS) - (first ? 0 : LEAD), dur = Math.round(end * FPS) - from + TAIL;
  return <Sequence from={from} durationInFrames={dur} layout="none"><Inner from={from} first={first} trans={trans} bg={bg} children={children} /></Sequence>;
};
const Inner: React.FC<{ from: number; first?: boolean; trans: Trans; bg: string; children: (c: Ctx) => React.ReactNode }> = ({ from, first, trans, bg, children }) => {
  const f = useCurrentFrame(), t = (f + from) / FPS;
  const k = first ? 1 : clamp(f / (LEAD + 2)), ke = Easing.out(Easing.cubic)(k);
  const sc = !first && trans === "zoom" ? lerp(1.35, 1, ke) : 1;
  const tx = !first && trans === "whip" ? (1 - ke) * 720 : 0, blur = !first && trans === "whip" ? (1 - ke) * 14 : 0;
  return (
    <AbsoluteFill style={{ opacity: first || trans === "flash" || trans === "whip" ? 1 : k, transform: `translateX(${tx}px) scale(${sc})`, background: bg, filter: `saturate(1.32) contrast(1.07) brightness(1.02)${blur > 0.2 ? ` blur(${blur.toFixed(1)}px)` : ""}` }}>
      <ThreeCanvas width={720} height={1280} camera={{ fov: 60, position: [0, 2, 8], near: 0.1, far: 400 }} gl={{ antialias: true }}>
        <color attach="background" args={[bg]} />{children({ t, f })}
      </ThreeCanvas>
      {!first && trans === "flash" ? <AbsoluteFill style={{ background: "#fff", opacity: 1 - clamp(f / 7) }} /> : null}
    </AbsoluteFill>
  );
};
const L3: React.FC<{ amb?: number; kc?: string; ki?: number; fc?: string }> = ({ amb = 1.5, kc = "#fff2d8", ki = 1.3, fc = "#9ab8ff" }) => (<><ambientLight intensity={amb} /><directionalLight position={[4, 8, 5]} intensity={ki} color={kc} /><directionalLight position={[-5, 3, 2]} intensity={0.5} color={fc} /></>);
const yawTo = (cam: V3, p: V3) => Math.atan2(cam[0] - p[0], cam[2] - p[2]);
const toWorld = (p: V3, loc: V3, cam: V3): V3 => { const y = yawTo(cam, p); return [p[0] + loc[0] * Math.cos(y) + loc[2] * Math.sin(y), p[1] + loc[1], p[2] - loc[0] * Math.sin(y) + loc[2] * Math.cos(y)]; };
const decay = (t: number, a: number, r: number) => (t < a ? 0 : Math.exp(-(t - a) * r));
const hit = (t: number, a: number, d: number) => (t > a && t < a + d ? Math.sin(((t - a) / d) * Math.PI) : 0);
// faint: wobble -> knees buckle -> gravity roll to the floor -> small bounce
const faint = (t: number, t0: number, dir: number) => {
  const pre = t > t0 - 0.4 && t < t0 + 0.05;
  const k = clamp((t - t0) / 0.42), b = t > t0 + 0.42 ? 0.07 * Math.exp(-(t - t0 - 0.42) * 9) * Math.sin((t - t0 - 0.42) * 26) : 0;
  return { roll: dir * (1.5 * k * k + b), squash: pre ? -0.1 : 0, tilt: pre ? Math.sin((t - t0) * 24) * 0.05 : 0, out: t > t0 + 0.25 };
};
const colLerp = (a: string, b: string, k: number) => "#" + new THREE.Color(a).lerp(new THREE.Color(b), clamp(k)).getHexString();

/* ---------- shared interior dressing ---------- */
const Pipes: React.FC<{ x0?: number; len?: number; colors?: string[] }> = ({ x0 = 0, len = 24, colors = ["#c9a24a", "#8c92a8", "#e5233a", "#2fae6a"] }) => (<>
  {([[5.6, -3.0, 0.17], [6.1, -2.2, 0.12], [5.3, 3.1, 0.18], [6.2, 2.0, 0.1], [2.0, -3.85, 0.1]] as number[][]).map(([y, z, r], i) => <Cyl key={i} p={[x0, y, z]} rt={r} h={len} rot={[0, 0, Math.PI / 2]} color={colors[i % colors.length]} line={2} />)}
  {Array.from({ length: Math.floor(len / 3) }, (_, i) => <Cyl key={"fl" + i} p={[x0 - len / 2 + 1.5 + i * 3, 5.6, -3.0]} rt={0.24} h={0.14} rot={[0, 0, Math.PI / 2]} color="#a8822e" line={2} />)}
</>);
const CageLamp: React.FC<{ p: V3; swing?: number; on?: number; color?: string }> = ({ p, swing = 0, on = 1, color = "rgba(255,226,150,1)" }) => (
  <group position={p} rotation={[0, 0, swing]}>
    <Cyl p={[0, -0.5, 0]} rt={0.025} h={1.0} color="#2b3350" line={1} />
    <Cyl p={[0, -1.05, 0]} rt={0.16} rb={0.36} h={0.24} color="#3a4048" line={2} />
    <Ball p={[0, -1.25, 0]} r={0.16} color={on > 0.5 ? "#fff2b0" : "#8a8060"} ink={0.02} />
    {on > 0.02 ? <Glow p={[0, -1.3, 0.1]} r={1.7} color={color} o={0.55 * on} /> : null}
  </group>
);
const Panel: React.FC<{ p: V3; s: [number, number]; rot?: V3; seed?: number; t: number; color?: string }> = ({ p, s, rot, seed = 1, t, color = "#3a4a5a" }) => (
  <CanvasPlane p={p} rot={rot} s={s} px={[Math.round(s[0] * 120), Math.round(s[1] * 120)]} frame="#2b3350" draw={(c, W, H) => {
    c.fillStyle = color; c.fillRect(0, 0, W, H); c.strokeStyle = "rgba(0,0,0,.35)"; c.lineWidth = 3; c.strokeRect(8, 8, W - 16, H - 16);
    for (let i = 0; i < 10; i++) { const x = 20 + ((i * 53 + seed * 17) % (W - 40)), y = 20 + ((i * 37 + seed * 29) % (H - 40)); const on = Math.sin(t * (2 + i) + i + seed) > 0.2; c.fillStyle = i % 3 === 0 ? (on ? "#ff4a4a" : "#5a2020") : i % 3 === 1 ? (on ? "#7aff9a" : "#1f4a2a") : "#e8e0c8"; c.beginPath(); c.arc(x, y, i % 3 === 2 ? 9 : 6, 0, 7); c.fill(); c.strokeStyle = INK; c.lineWidth = 2; c.stroke(); }
  }} />
);

/* =================== S1 0 – 3.0  "The air inside B-59 is poison." =================== */
const K1: Key[] = [
  { t: 0, pos: [10.5, 8.2, 15], look: [3.0, 7.2, 0], fov: 46 },
  { t: 1.15, pos: [6.5, 6.0, 12.5], look: [1.6, 3.6, 0], fov: 50 },
  { t: 1.75, pos: [1.8, 3.4, 6.6], look: [0.4, 2.2, 0], fov: 54 },
  { t: 2.15, pos: [0.6, 2.7, 3.1], look: [-0.3, 1.4, -3], fov: 56 },
  { t: 3.2, pos: [0.3, 2.6, 2.6], look: [-0.4, 1.3, -3], fov: 56 },
];
const S1 = ({ t, f }: Ctx) => {
  const c = camAt(t, K1).pos, inside = Math.hypot(c[1] - HC, c[2]) < HR - 0.05, gas = seg(t, 1.85, 2.5);
  const cough = [2.2, 2.55, 2.85].reduce((a, ti) => a + hit(t, ti, 0.18), 0);
  return (<>
    <Cam t={t} keys={K1} />
    <FogSet color={inside ? "#24501a" : "#06385a"} near={inside ? 2 : 12} far={inside ? 15 : 75} />
    <L3 amb={1.6} kc={inside ? "#d8ffb0" : "#bfe8ff"} />
    <Sub p={[0, HC, 0]} t={t} />
    {!inside ? <>
      {[-14, -4, 8, 18].map((x, i) => <Shaft key={i} p={[x, 18, -6 + i * 2]} s={[4, 30]} rot={[0, 0, 0.25]} color="150,230,255" o={0.22} />)}
      {Array.from({ length: 20 }, (_, i) => <Glow key={i} p={[-12 + i * 1.4, HC + ((t * 1.6 + i * 0.83) % 12) - 2, 5.2 + (i % 3) * 0.8]} r={0.12 + (i % 3) * 0.05} color="rgba(210,245,255,1)" o={0.9} />)}
      <Dust t={t} n={14} area={[14, 14, 6]} color="rgba(170,230,255,.9)" />
      {[[-8, 13, -10], [14, 10, -14]].map(([x, y, z], i) => <group key={i} position={[x + (t * 0.8) * (i ? -1 : 1), y, z]} rotation={[0, i ? Math.PI : 0, 0]}>{Array.from({ length: 6 }, (_, k) => <Ball key={k} p={[k * 0.9, Math.sin(k * 2.1 + t * 3) * 0.3, (k % 2) * 0.6]} r={0.22} s={[1.8, 1, 0.6]} color="#ffb03a" ink={0.04} />)}</group>)}
    </> : null}
    {/* interior (only seen once the camera has passed the hull) */}
    <HullRoom wall={["#4d6b45", "#46623f"]} floor={["#333a30", "#2c3229"]} rib="#243022" />
    <Pipes />
    <Gauge p={[-2.0, 4.3, -3.95]} v={0.18} label="O2" red={0.0} /><Gauge p={[0.9, 4.6, -3.75]} v={0.92} label="CO2" />
    <Valve p={[-3.2, 3.2, -4.0]} /><Panel p={[2.6, 3.0, -3.9]} s={[1.6, 1.6]} t={t} seed={3} color="#2f4a3a" />
    <Cabinet p={[-3.6, 0, -2.6]} color="#5a7a5a" /><Cabinet p={[3.8, 0, -2.6]} w={1.2} color="#5a7a5a" />
    <CageLamp p={[0, 7.6, -0.6]} color="rgba(190,255,120,1)" />
    {Array.from({ length: 8 }, (_, i) => <Glow key={"g" + i} p={[-3.4 + i, 1.0 + (i % 3) * 1.3 + Math.sin(t * 0.9 + i) * 0.25, -2.6 + (i % 2) * 1.8]} r={1.9} color="rgba(140,255,70,1)" o={0.3 * gas} />)}
    <P3 p={[-0.5, 0, -1.4]} h={3.3} look={sailors[0]} f={f} pose={{ mood: "gulp", arms: "chest", armK: 1, hunch: 0.6 + cough * 0.3, nerv: 0.4, sweat: 1, squash: -0.05 * cough, nod: cough * 0.6, lookX: -0.3 }} />
    <P3 p={[2.2, 0, -2.1]} h={3.1} look={sailors[1]} f={f} roll={-1.5} pose={{ t: 98, mood: "deadpan" }} />
  </>);
};

/* =================== S2 3.0 – 8.4  "Forty-five degrees, batteries dying, carbon dioxide dropping men where they stand." =================== */
const K2: Key[] = [
  { t: 2.8, pos: [8.6, 3.5, 0.6], look: [6.0, 3.1, -3.4], fov: 46 },
  { t: 4.3, pos: [8.6, 3.3, 0.9], look: [4.0, 2.2, 2.4], fov: 52 },
  { t: 5.6, pos: [8.2, 3.4, 0.6], look: [3.6, 3.4, -3.2], fov: 54 },
  { t: 6.6, pos: [7.4, 3.2, 0.9], look: [1.4, 1.2, -0.6], fov: 54 },
  { t: 8.6, pos: [6.4, 3.4, 1.1], look: [-2.0, 0.9, 0.4], fov: 54 },
];
const S2 = ({ t, f }: Ctx) => {
  const heat = seg(t, 3.05, 3.75, Easing.out(Easing.cubic)), batt = 1 - seg(t, 4.4, 5.3, Easing.inOut(Easing.sin));
  const dim = t < 5.04 ? 1 : t < 5.7 ? (Math.sin(f * 1.9) * Math.sin(f * 0.71) > 0.15 ? 0.25 : 0.75) : 0.45;
  const co2 = lerp(0.35, 0.95, seg(t, 5.74, 6.5));
  const A = faint(t, 6.75, 1), B = faint(t, 7.75, -1);
  const reach = seg(t, 6.95, 7.25);
  return (<>
    <Cam t={t} keys={K2} />
    <FogSet color="#3a1206" near={4} far={22} />
    <L3 amb={0.8 + 0.8 * dim} kc="#ffb070" fc="#ff6a3a" />
    <HullRoom wall={["#9a4a26", "#8e4322"]} floor={["#3a2a22", "#33241d"]} rib="#3a1a0e" />
    <Pipes colors={["#c9a24a", "#6a5a4a", "#e5233a", "#c9a24a"]} />
    <Thermo p={[6.3, 3.6, -3.4]} rot={[0, 0.75, 0]} v={lerp(0.5, 0.94, heat)} text={`${Math.round(lerp(31, 45, heat))}°C`} />
    <Glow p={[6.0, 3.6, -3.0]} r={1.8} color="rgba(255,80,40,1)" o={0.35 * heat} />
    {/* battery banks + charge display */}
    {[-1, 1].map((sd) => Array.from({ length: 16 }, (_, i) => <group key={sd + "," + i} position={[-9.5 + i * 0.95, 0, sd * 2.45]}>
      <Box p={[0, 0.45, 0]} s={[0.8, 0.9, 0.9]} color={i % 2 ? "#2b3a4a" : "#33465a"} line={2} />
      <Cyl p={[-0.2, 0.98, 0]} rt={0.08} h={0.14} color="#e5233a" line={1} /><Cyl p={[0.2, 0.98, 0]} rt={0.08} h={0.14} color="#1b1b2a" line={1} />
    </group>))}
    <CanvasPlane p={[4.4, 3.4, 3.35]} rot={[0, Math.PI - 0.75, 0]} s={[1.9, 1.1]} px={[380, 220]} frame="#2b3350" draw={(c, W, H) => {
      c.fillStyle = "#101820"; c.fillRect(0, 0, W, H); c.fillStyle = "#9fdcff"; c.font = "900 34px Inter, Arial"; c.textAlign = "left"; c.fillText("BATTERY", 18, 44);
      const n = Math.ceil(batt * 8); for (let i = 0; i < 8; i++) { c.fillStyle = i < n ? (batt < 0.3 ? "#ff3b3b" : batt < 0.6 ? "#ffc23a" : "#36e07a") : "#22303a"; c.fillRect(18 + i * 44, 70, 36, 110); c.strokeStyle = INK; c.lineWidth = 4; c.strokeRect(18 + i * 44, 70, 36, 110); }
      if (batt < 0.3 && Math.sin(f * 0.9) > 0) { c.fillStyle = "#ff3b3b"; c.font = "900 30px Inter, Arial"; c.textAlign = "right"; c.fillText("LOW", W - 18, 44); }
    }} />
    <Gauge p={[3.2, 4.4, -3.75]} rot={[0, 0.5, 0]} v={co2} label="CO2" r={0.55} />
    <Gauge p={[1.6, 4.7, -3.62]} rot={[0, 0.4, 0]} v={0.82 - 0.1 * heat} label="BAR" r={0.4} red={0.8} />
    <Valve p={[-1.0, 3.4, -4.0]} /><Valve p={[5.2, 2.8, 3.95]} rot={[0, Math.PI, 0]} color="#ffc23a" />
    <Cabinet p={[-6.0, 0, -2.3]} w={1.2} h={1.6} color="#7a4a3a" /><Panel p={[-3.6, 3.6, -3.9]} s={[1.6, 1.2]} t={t} seed={5} color="#5a3a2a" />
    {[7, 3, -1, -5, -9].map((x, i) => <CageLamp key={i} p={[x, 7.6, 0]} on={dim} color="rgba(255,190,110,1)" />)}
    {Array.from({ length: 6 }, (_, i) => <Glow key={"h" + i} p={[-6 + i * 2.6, 3 + Math.sin(t * 1.3 + i) * 0.4, -1 + (i % 2) * 2]} r={2.2} color="rgba(255,120,40,1)" o={0.16 * heat} />)}
    <Dust t={t} area={[6, 6, 3]} color="rgba(255,200,140,.9)" />
    {/* sailors: one fans himself, two collapse */}
    <P3 p={[-4.6, 0, -1.3]} h={3.2} look={sailors[2]} f={f} pose={{ mood: t < 6.85 ? "worry" : "shock", sweat: 1, nerv: t < 6.85 ? 0.25 : 0.6, armR: t < 6.9 ? [0.17 + 0.04 * Math.sin(f * 0.9), 0.62] : [0.34, 0.5], armRK: t < 6.9 ? 1 : reach, lookX: t < 6.8 ? 0 : 1, hunch: 0.3 }} />
    <P3 p={[2.3, 0, -0.9]} h={3.2} look={sailors[0]} f={f} roll={A.roll} pose={{ t: A.out ? 98 : undefined, mood: A.out ? "deadpan" : "gulp", sweat: A.out ? 0 : 1, nerv: A.out ? 0 : 0.35, squash: A.squash, tilt: A.tilt, hunch: 0.5, arms: A.out ? "down" : "chest", armK: 1 }} />
    <P3 p={[-2.1, 0, 0.7]} h={3.1} look={sailors[3]} f={f} roll={B.roll} pose={{ t: B.out ? 98 : undefined, mood: B.out ? "deadpan" : t > 7.0 ? "worry" : "gulp", sweat: B.out ? 0 : 1, nerv: B.out ? 0 : 0.3, squash: B.squash, tilt: B.tilt, hunch: 0.4, lookX: 1 }} />
  </>);
};

/* =================== S3 8.4 – 12.75  "Above them, American destroyers hammer the water with depth charges," =================== */
const SURF = 38;
const K3: Key[] = [
  { t: 8.2, pos: [15, 28, 17], look: [6, 38, -4], fov: 60 },
  { t: 10.3, pos: [14, 28, 16], look: [3, 38, -3], fov: 60 },
  { t: 11.2, pos: [19, 19, 26], look: [2, 23, -2], fov: 60 },
  { t: 12.0, pos: [18, 8, 28], look: [1, 9.5, 0], fov: 60 },
  { t: 12.95, pos: [19, 9, 29], look: [1, 8.5, 0], fov: 58 },
];
const d1x = (t: number) => 12 + (t - 10.5) * 3.2;
const CH = [0, 1, 2, 3].map((i) => { const r = 10.42 + i * 0.17, x0 = d1x(r) - 10.6, z = (i % 2 ? 1 : -1) * (2.4 + i * 0.35) - 2; return { r, x0, z, E: 12.0 + i * 0.2 }; });
const chargePos = (c: { r: number; x0: number; z: number }, t: number): V3 => { const dt = Math.max(0, t - c.r); const fall = dt < 0.12 ? 0 : (dt - 0.12); return [c.x0 + Math.min(dt, 0.12) * -3 - fall * 0.6, SURF + 1.7 - Math.min(dt, 0.12) * 14 - fall * 18.5 - fall * fall * 1.5, c.z]; };
const S3 = ({ t, f }: Ctx) => {
  const rock = CH.reduce((a, c) => a + (t > c.E ? 0.05 * Math.exp(-(t - c.E) * 3) * Math.sin((t - c.E) * 14) : 0), 0);
  return (<>
    <Cam t={t} keys={K3} impacts={CH.map((c) => [c.E, 0.1 - CH.indexOf(c) * 0.015] as [number, number])} />
    <FogSet color="#0a4a78" near={18} far={95} />
    <L3 amb={1.5} kc="#bfe8ff" />
    <SurfaceBelow y={SURF} t={t} />
    {[-24, -10, 4, 18, 30].map((x, i) => <Shaft key={i} p={[x, SURF - 14, -10 + (i % 2) * 8]} s={[6, 30]} rot={[0, 0.3 * i, 0.2]} color="170,235,255" o={0.24} />)}
    <Destroyer p={[d1x(t), SURF, -2]} s={1.6} num="850" />
    <Destroyer p={[d1x(t) - 26, SURF, -16]} s={1.6} num="827" />
    <Sub p={[0, HC, 0]} rot={[rock * 0.4, 0, rock]} t={t} />
    {CH.map((c, i) => { if (t < c.r) return null; const p = chargePos(c, t); const ex = t >= c.E, k = ex ? clamp((t - c.E) / 0.25) : 0;
      return <React.Fragment key={i}>
        {!ex ? <><DepthCharge p={p} rot={[t * 2 + i, 0, t * 3 + i]} s={1.6} />{Array.from({ length: 5 }, (_, b) => <Glow key={b} p={[p[0] + Math.sin(b * 3 + i) * 0.4, p[1] + 1 + b * 0.9, p[2]]} r={0.18} color="rgba(220,250,255,1)" o={0.8} />)}</> : null}
        {t > c.r && t < c.r + 0.6 ? <Glow p={[c.x0, SURF - 0.3, c.z]} r={3 * seg(t, c.r, c.r + 0.2)} color="rgba(255,255,255,1)" o={1 - seg(t, c.r + 0.2, c.r + 0.6)} /> : null}
        {ex && t < c.E + 1.2 ? <>
          <Glow p={[p[0], p[1], p[2] + 1]} r={2 + 8 * k} color="rgba(255,250,210,1)" o={1 - seg(t, c.E + 0.15, c.E + 0.9)} />
          {Array.from({ length: 12 }, (_, b) => { const a = b * 0.52, d = (t - c.E); return <Ball key={b} p={[p[0] + Math.cos(a) * d * 7, p[1] + Math.sin(a * 1.7) * d * 5 + d * d * 6, p[2] + Math.sin(a) * d * 5]} r={0.25 + (b % 3) * 0.15} color="#e8fbff" ink={0.04} />; })}
        </> : null}
      </React.Fragment>; })}
    <Dust t={t} n={16} area={[16, 20, 8]} color="rgba(190,240,255,.9)" />
  </>);
};

/* =================== S4 12.75 – 15.95  "and every blast rings the hull like a bell." =================== */
const BL = [13.49, 13.98];
const K4: Key[] = [
  { t: 12.55, pos: [9.4, 1.5, 1.6], look: [0, 3.0, -0.4], fov: 64 },
  { t: 13.9, pos: [8.2, 1.5, 1.2], look: [-2, 3.2, 0], fov: 62 },
  { t: 15.0, pos: [3.2, 2.7, 0.7], look: [-11, 3.9, 0], fov: 52 },
  { t: 16.15, pos: [-1.2, 3.4, 0.4], look: [-12, 4.1, 0], fov: 44 },
];
const S4 = ({ t, f }: Ctx) => {
  const wave = (x: number) => BL.reduce((a, b) => { const fr = 12 - (t - b) * 38; return a + (t > b ? Math.exp(-((x - fr) ** 2) / 3) * Math.exp(-(t - b) * 1.2) : 0); }, 0);
  const swing = BL.reduce((a, b) => a + (t > b ? 0.32 * Math.exp(-(t - b) * 1.3) * Math.sin((t - b) * 6.5) : 0), 0);
  const bellSw = BL.reduce((a, b) => a + (t > b + 0.3 ? 0.28 * Math.exp(-(t - b - 0.3) * 1.1) * Math.sin((t - b - 0.3) * 7) : 0), 0) + (t > 15.0 ? 0.22 * Math.exp(-(t - 15.0) * 1.5) * Math.sin((t - 15.0) * 7.5) : 0);
  const flinch = BL.reduce((a, b) => a + hit(t, b, 0.25), 0);
  const ringK = [13.85, 14.35, 15.12].map((r) => (t > r ? clamp((t - r) / 0.9) : 0));
  const drip = t > 13.55;
  return (<>
    <Cam t={t} keys={K4} impacts={BL.map((b) => [b, 0.06] as [number, number])} />
    <FogSet color="#0c1e3a" near={6} far={30} />
    <L3 amb={1.5} kc="#cfe0ff" />
    <HullRoom wall={["#4f73a0", "#486a94"]} floor={["#25304a", "#202a42"]} rib="#1a2338" ribColor={(x) => colLerp("#1a2338", "#bff4ff", wave(x))} caps={["#33476e", null]} />
    {Array.from({ length: 9 }, (_, i) => { const x = -10.8 + i * 2.4, g = wave(x); return g > 0.08 ? <Glow key={i} p={[x, HC + HR - 0.6, 0]} r={1.4} color="rgba(170,240,255,1)" o={0.7 * g} /> : null; })}
    <Pipes x0={0} />
    {/* bunks on the near-left side */}
    {[2.5, 6.5].map((x) => <group key={x} position={[x, 0, 2.3]}>{[0.9, 2.4, 3.9].map((y) => <React.Fragment key={y}><Box p={[0, y, 0]} s={[3.2, 0.14, 1.0]} color="#5a6a7a" line={2} /><Box p={[0, y + 0.14, 0]} s={[3.0, 0.16, 0.9]} color="#e8e0c8" line={2} /></React.Fragment>)}<Box p={[-1.6, 2.2, 0.45]} s={[0.1, 4.4, 0.1]} color="#2b3350" line={2} /><Box p={[1.6, 2.2, 0.45]} s={[0.1, 4.4, 0.1]} color="#2b3350" line={2} /></group>)}
    <Shelf p={[-4.8, 0, -2.9]} w={2.2} rows={3} seed={4} wood="#3a4a66" />
    <Gauge p={[1.0, 4.2, -3.95]} v={0.55 + 0.25 * Math.sin(t * 9) * decay(t, 13.49, 2)} label="DEPTH" />
    <Panel p={[-1.6, 3.4, -3.95]} s={[1.4, 1.4]} t={t} seed={8} color="#2f3f5a" /><Valve p={[3.6, 3.6, -3.95]} spin={swing} />
    {[9, 4.5, 0, -4.5, -9].map((x, i) => <CageLamp key={i} p={[x, 7.6, -0.4]} swing={swing * (1 + i * 0.1)} color="rgba(200,230,255,1)" />)}
    {/* leak after the first blast: drops fall with gravity and splash */}
    {drip ? Array.from({ length: 6 }, (_, i) => { const u = ((t - 13.55) * 1.6 + i / 6) % 1; return <Glow key={"d" + i} p={[-0.6, 5.5 - u * u * 5.4, -2.95]} r={0.12} color="rgba(160,220,255,1)" o={0.95} />; }) : null}
    {/* the bell on the far bulkhead */}
    <ShipBell p={[-11.9, 5.4, 0]} swing={bellSw} clap={-bellSw * 1.6} />
    {ringK.map((k, i) => k > 0 && k < 1 ? <Ring key={"rk" + i} p={[-11.8, 4.75, 0]} R={0.6 + k * 2.4} r={0.05} rot={[0, Math.PI / 2, 0]} color="#fff3b0" ink={0} /> : null)}
    <Glow p={[-11.6, 4.8, 0]} r={2.2} color="rgba(255,220,120,1)" o={0.25 + 0.5 * ringK.reduce((a, k) => a + (k > 0 && k < 1 ? 1 - k : 0), 0)} />
    {/* crew */}
    <P3 p={[3.4, 0, -1.7]} h={3.3} look={sailors[1]} f={f} pose={{ mood: flinch > 0.2 ? "shock" : "worry", arms: "head", armK: 1, hunch: 0.5 + flinch * 0.4, squash: -0.12 * flinch, nerv: 0.5, sweat: 1, lookX: -0.6 }} />
    <P3 p={[0.4, 0, 1.2]} h={3.2} look={sailors[3]} f={f} pose={{ mood: "worry", armR: [0.12, 0.98], armL: [-0.12, 0.98], nerv: 0.3 + flinch * 0.3, sweat: 0.7, squash: -0.06 * flinch, lookX: 0.5 }} />
    <P3 p={[2.5, 1.12, 2.2]} h={2.9} look={sailors[0]} f={f} roll={-1.52} shadow={false} pose={{ mood: flinch > 0.2 ? "shock" : "worry", sweat: 0.6, nerv: 0.3 }} />
    <P3 p={[-3.0, 0, -0.4]} h={3.1} look={sailors[2]} f={f} pose={{ mood: "worry", lookX: -1, nerv: 0.3, sweat: 0.6, hunch: 0.3 + flinch * 0.3, arms: flinch > 0.2 ? "head" : "chest", armK: 1 }} />
  </>);
};

/* =================== S5 15.95 – 21.55  "Captain Savitsky hasn't heard from Moscow in days. He's sure the war has already begun." =================== */
const K5: Key[] = [
  { t: 15.75, pos: [-1.2, 2.9, 0.6], look: [-1.6, 2.6, -3.4], fov: 48 },
  { t: 17.3, pos: [-0.2, 3.2, 3.0], look: [-0.4, 0.9, -2.6], fov: 56 },
  { t: 18.5, pos: [0.8, 4.2, 1.6], look: [1.4, 4.4, -3.6], fov: 50 },
  { t: 19.6, pos: [0.1, 3.1, 3.0], look: [0.0, 0.9, -2.6], fov: 54 },
  { t: 21.0, pos: [-0.6, 3.6, 2.0], look: [-1.4, 4.0, -3.4], fov: 52 },
  { t: 21.75, pos: [-0.5, 3.5, 2.2], look: [-1.0, 3.6, -3.2], fov: 52 },
];
const TEAR0 = 18.5, TEARD = 0.12, NT = 5;
const S5 = ({ t, f }: Ctx) => {
  const P: V3 = [-0.1, 0, -1.0], torn = t < TEAR0 ? 0 : Math.min(NT, Math.floor((t - TEAR0) / TEARD) + 1);
  const ear = t < 19.5, sure = seg(t, 19.46, 19.8), fist = seg(t, 20.05, 20.25, Easing.out(Easing.back(2)));
  const warK = (i: number) => seg(t, 20.13 + i * 0.07, 20.3 + i * 0.07, Easing.out(Easing.back(3)));
  const cal: V3 = [1.4, 4.9, -3.55];
  return (<>
    <Cam t={t} keys={K5} fovKick={[20.13]} />
    <FogSet color="#2a1606" near={5} far={22} />
    <L3 amb={1.5} kc="#ffd29a" />
    <HullRoom wall={["#b0702e", "#a2652a"]} floor={["#5a3a22", "#50331e"]} rib="#3a2414" kind="wood" />
    <Pipes colors={["#c9a24a", "#7a5a3a", "#e5233a", "#c9a24a"]} />
    {/* radio set */}
    <Box p={[-1.8, 2.3, -3.1]} s={[2.4, 3.4, 0.9]} color="#5a6a48" />
    <CanvasPlane p={[-1.8, 2.95, -2.64]} s={[2.1, 1.3]} px={[420, 260]} draw={(c, W, H) => {
      c.fillStyle = "#1a2216"; c.fillRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 8; c.strokeRect(4, 4, W - 8, H - 8);
      c.fillStyle = "#f4e6b0"; c.fillRect(20, 20, W - 40, 70); c.fillStyle = INK; c.font = "800 22px Inter, Arial"; c.textAlign = "center"; ["MURMANSK", "MOSCOW", "SEVEROMORSK"].forEach((s, i) => c.fillText(s, 80 + i * 130, 48));
      for (let i = 0; i < 30; i++) { c.fillRect(24 + i * 12.5, 66, 2, i % 5 ? 10 : 18); }
      const nx = 210 + Math.sin(t * 1.7) * 30 + Math.sin(t * 5.3) * 8; c.fillStyle = "#e5233a"; c.fillRect(nx, 22, 5, 66);
      c.fillStyle = "#0a160a"; c.fillRect(20, 110, W - 40, 130); c.strokeStyle = "#5aff7a"; c.lineWidth = 3; c.beginPath();
      for (let x = 0; x < W - 40; x += 4) { const y = 175 + (Math.sin(x * 0.9 + f * 3.1) * Math.sin(x * 0.13 + f) * 9); x ? c.lineTo(20 + x, y) : c.moveTo(20 + x, y); } c.stroke();
      if (t > 17.84 && Math.sin(f * 0.8) > -0.3) { c.fillStyle = "#ff3b3b"; c.font = "900 44px Inter, Arial"; c.fillText("NO SIGNAL", W / 2, 150); }
    }} />
    {[-2.6, -2.1, -1.6, -1.1].map((x, i) => <Cyl key={x} p={[x, 1.9, -2.62]} rt={0.12} h={0.12} rot={[Math.PI / 2, 0, 0]} color={i % 2 ? "#e8e0c8" : "#2b3350"} line={2} />)}
    <Desk p={[-1.8, 0, -2.0]} w={2.6} d={1.0} top="#7a4a22" leg="#5a3418" />
    <Cyl p={[-2.6, 1.3, -1.9]} rt={0.05} h={0.5} color="#2b3350" line={1} /><Ball p={[-2.6, 1.6, -1.9]} r={0.13} color="#2b3350" ink={0.02} />
    <Mug2 p={[-1.0, 1.12, -1.8]} />
    {/* world map: war lights */}
    <CanvasPlane p={[-1.6, 5.15, -3.4]} s={[2.6, 1.4]} px={[520, 280]} frame="#3a2414" draw={(c, W, H) => {
      c.fillStyle = "#2a6fb8"; c.fillRect(0, 0, W, H);
      const blobs: [number, number, number, number][] = [[110, 90, 70, 50], [150, 190, 40, 60], [270, 80, 60, 40], [290, 170, 40, 55], [400, 100, 90, 50], [440, 210, 35, 25]];
      for (const [x, y, rx, ry] of blobs) { c.fillStyle = "#e8d8a8"; c.strokeStyle = INK; c.lineWidth = 4; c.beginPath(); c.ellipse(x, y, rx, ry, 0.2, 0, 7); c.fill(); c.stroke(); }
      const pts = [[120, 80], [140, 110], [100, 100], [280, 70], [300, 90], [420, 90], [390, 110], [450, 80], [160, 180], [290, 160]];
      pts.forEach(([x, y], i) => { const k = warK(i); if (k <= 0) return; c.fillStyle = "#ff2b2b"; c.beginPath(); c.arc(x, y, 12 * k, 0, 7); c.fill(); c.strokeStyle = `rgba(255,80,40,${1 - ((t * 2 + i * 0.3) % 1)})`; c.lineWidth = 4; c.beginPath(); c.arc(x, y, 12 + ((t * 2 + i * 0.3) % 1) * 30, 0, 7); c.stroke(); });
      if (t > 20.9) { c.fillStyle = "#ff2b2b"; c.strokeStyle = "#000"; c.lineWidth = 10; c.font = "900 90px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.strokeText("WAR?", W / 2, H / 2); c.fillText("WAR?", W / 2, H / 2); }
    }} />
    <Glow p={[-1.6, 5.1, -3.0]} r={2.4} color="rgba(255,60,40,1)" o={0.45 * warK(9)} />
    {/* tear-off calendar: days pass */}
    <Calendar p={cal} month="OCT" day={String(22 + torn)} s={1.25} />
    {Array.from({ length: torn }, (_, k) => { const dt = t - (TEAR0 + k * TEARD); const y = cal[1] + 1.1 * dt - 2.1 * dt * dt, land = y <= 0.04; const tl = (1.1 + Math.sqrt(1.21 + 8.4 * (cal[1] - 0.04))) / 4.2, q = Math.min(dt, tl);
      const pp: V3 = [cal[0] + (0.7 + 0.25 * k) * q, land ? 0.04 : y, cal[2] + 0.2 + (1.3 + 0.2 * k) * q];
      return <CanvasPlane key={k} p={pp} rot={land ? [-Math.PI / 2, 0, k] : [q * 2.5, q * 1.6 + k, q * 4]} s={[1.25, 1.44]} px={[200, 230]} draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = "#e23b3b"; c.fillRect(0, 0, W, 60); c.fillStyle = INK; c.font = "900 120px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(String(22 + k), W / 2, 140); c.strokeStyle = INK; c.lineWidth = 6; c.strokeRect(3, 3, W - 6, H - 6); }} />; })}
    <Gauge p={[3.0, 4.3, -3.75]} rot={[0, -0.3, 0]} v={0.4} label="kHz" /><Cabinet p={[3.6, 0, -2.6]} w={1.4} color="#7a5a3a" /><Panel p={[2.2, 2.6, -3.9]} s={[1.0, 1.5]} t={t} seed={2} color="#5a4a2a" />
    <CageLamp p={[0.2, 7.6, -0.6]} color="rgba(255,210,140,1)" />
    <Dust t={t} area={[4, 6, 2]} color="rgba(255,220,170,.9)" />
    {/* the captain */}
    <P3 p={P} h={3.4} look={capt} f={f} pose={{ mood: t < 19.5 ? "worry" : t < 20.1 ? "angry" : "scream", nerv: t < 19.5 ? 0.25 : t < 20.1 ? 0.3 : 0.7, sweat: t > 18.4 ? 0.8 : 0.3,
      armR: ear ? [-0.23, 0.6] : fist > 0 ? [0.24, lerp(0.6, 0.95, fist)] : [0.24, 0.42], armRK: ear ? 1 : fist > 0 ? 1 : 1 - sure * 0.6, tilt: ear ? -0.05 : 0, lookX: t < 19.5 ? -0.8 : t < 20.2 ? 0 : -0.6,
      squash: hit(t, 20.1, 0.3) * 0.08 - hit(t, 19.9, 0.2) * 0.06 }} />
    <FaceGroup p={P}>{ear ? <Cyl p={hand(3.4, [-0.23, 0.6], 0, false, 0.12)} rt={0.12} h={0.12} rot={[Math.PI / 2, 0, 0]} color="#1b1b2a" line={2} /> : null}</FaceGroup>
  </>);
};
const Mug2: React.FC<{ p: V3 }> = ({ p }) => (<group position={p}><Cyl p={[0, 0.18, 0]} rt={0.17} rb={0.15} h={0.36} color="#e8e0c8" line={2} /><Box p={[0.21, 0.18, 0]} s={[0.09, 0.2, 0.05]} color="#e8e0c8" line={2} /></group>);

/* =================== S6 21.55 – 24.95  "He screams the order: arm the nuclear torpedo." =================== */
const K6: Key[] = [
  { t: 21.4, pos: [0.4, 1.3, 2.4], look: [3.2, 1.5, -1.4], fov: 52 },
  { t: 22.6, pos: [0.7, 1.4, 2.2], look: [3.3, 1.5, -1.4], fov: 46 },
  { t: 23.4, pos: [2.8, 2.7, 2.7], look: [9.0, 1.8, 0.4], fov: 56 },
  { t: 24.3, pos: [5.6, 2.8, 2.5], look: [11.5, 2.1, 0.6], fov: 54 },
  { t: 25.15, pos: [6.6, 2.9, 2.3], look: [11.6, 2.4, 0.6], fov: 52 },
];
const TX = (t: number) => lerp(7.6, 14.6, seg(t, 23.3, 24.25, Easing.inOut(Easing.sin)));
const S6 = ({ t, f }: Ctx) => {
  const x = TX(t), tail = x - 2.9, push = t > 23.3 && t < 24.25;
  const door = t < 24.3 ? 1.55 : 1.55 * (1 - seg(t, 24.3, 24.6, Easing.in(Easing.quad))), clank = t > 24.6;
  const beacon = 0.5 + 0.5 * Math.sin(f * 0.55);
  const pre = t > 21.55 && t < 21.8;
  const sail = (i: number): V3 => { const sx = Math.min(tail - 0.4 - i * 0.2, 10.4 - i * 0.3); return [sx, 0, i ? -1.3 : -0.35]; };
  return (<>
    <Cam t={t} keys={K6} fovKick={[21.8]} impacts={[[24.6, 0.02]]} />
    <FogSet color="#2a0606" near={5} far={24} />
    <L3 amb={1.0 + 0.5 * beacon} kc="#ff7a6a" fc="#ff3030" />
    <HullRoom wall={["#7a3a3a", "#6e3434"]} floor={["#3a2a2a", "#332424"]} rib="#2a1414" />
    <Bulkhead x={11.95} face={-1} color="#5a4a4a" hole={{ y: 2.2, rx: 0.52, ry: 0.52, z: 0.9 }} />
    <mesh position={[14.0, 2.2, 0.9]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.52, 0.52, 4.1, 24, 1, true]} /><meshBasicMaterial color="#0a0606" side={THREE.BackSide} /></mesh>
    <Ring p={[11.9, 2.2, -0.9]} R={0.52} r={0.08} rot={[0, Math.PI / 2, 0]} color="#c9a24a" />
    <Cyl p={[11.88, 2.2, -0.9]} rt={0.52} h={0.08} rot={[0, 0, Math.PI / 2]} color="#6a5a5a" line={2} />
    <group position={[11.88, 2.2, 0.9 + 0.55]} rotation={[0, door, 0]}><Cyl p={[0, 0, -0.55]} rt={0.55} h={0.1} rot={[0, 0, Math.PI / 2]} color="#7a6a6a" line={3} /><Valve p={[-0.08, 0, -0.55]} r={0.22} rot={[0, -Math.PI / 2, 0]} spin={clank ? (t - 24.6) * 6 : 0} color="#c9a24a" /></group>
    <CanvasPlane p={[11.85, 3.5, 0.9]} rot={[0, -Math.PI / 2, 0]} s={[1.4, 0.5]} px={[280, 100]} frame="#2b3350" draw={(c, W, H) => { const on = clank && Math.sin(f * 0.8) > -0.5; c.fillStyle = on ? "#ff2b2b" : "#3a1010"; c.fillRect(0, 0, W, H); c.fillStyle = on ? "#fff" : "#6a3030"; c.font = "900 60px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("ARMED", W / 2, H / 2 + 3); }} />
    {/* rails + torpedo racks */}
    {[0.65, 1.15].map((z) => <Box key={z} p={[8, 1.72, z]} s={[8, 0.1, 0.1]} color="#8c92a8" line={2} />)}
    {[5, 7.5, 10].map((xx) => <Box key={xx} p={[xx, 0.86, 0.9]} s={[0.2, 1.72, 0.9]} color="#3a3a4a" line={2} />)}
    <Torpedo p={[x, 2.2, 0.9]} />
    <Torpedo p={[7.4, 1.0, -2.0]} nuke={false} color="#6a7a5a" /><Torpedo p={[7.4, 4.8, -2.4]} nuke={false} color="#6a7a5a" />
    <Box p={[7.4, 0.4, -2.0]} s={[5, 0.2, 0.9]} color="#3a3a4a" line={2} />
    <Pipes colors={["#c9a24a", "#6a5a5a", "#e5233a", "#c9a24a"]} />
    <Gauge p={[9.6, 4.6, -3.7]} rot={[0, -0.4, 0]} v={0.3 + 0.6 * seg(t, 23.3, 24.3)} label="PSI" />
    <Panel p={[3.0, 3.2, -3.95]} s={[1.6, 1.4]} t={t} seed={11} color="#4a2a2a" />
    {/* rotating alarm beacon */}
    <group position={[6, 7.45, 0]}><Cyl p={[0, 0, 0]} rt={0.25} h={0.3} color="#e5233a" line={2} /><Glow p={[Math.sin(f * 0.55) * 0.6, -0.4, Math.cos(f * 0.55) * 0.6]} r={2.6} color="rgba(255,40,30,1)" o={0.6} /></group>
    <Glow p={[8, 3, 0]} r={6} color="rgba(255,30,30,1)" o={0.12 * beacon} />
    {/* loading crew */}
    {[0, 1].map((i) => { const sp = sail(i), mv = push && sp[0] < 10.3 - i * 0.3; return <P3 key={i} p={sp} h={3.2} look={sailors[i + 1]} f={f} pose={{ mood: "angry", walk: mv ? (sp[0] - 3) * WALK : undefined, speed: mv ? 0.7 : 0, armR: [0.24, 0.66], armL: [0.16, 0.62], tilt: mv ? 0.08 : 0, sweat: 0.6, lookX: 1 }} />; })}
    {/* the captain screams the order */}
    <P3 p={[3.2, 0, -1.4]} h={3.4} look={capt} f={f} pose={{ mood: t < 21.7 ? "angry" : "scream", nerv: t > 21.8 && t < 23.0 ? 0.75 : 0.3, sweat: 1, squash: pre ? -0.1 : t < 22.1 ? 0.08 * hit(t, 21.78, 0.35) / 1 : 0,
      armR: t < 21.75 ? undefined : [0.42, 0.66], armRK: seg(t, 21.72, 21.85), arms: "up", armK: t < 22.4 ? seg(t, 21.75, 21.9) * 0.6 : 0, lookX: 1, tilt: t > 21.78 && t < 22.8 ? -0.05 : 0 }} />
  </>);
};

/* =================== S7 24.95 – 28.9  "The political officer agrees. But launch needs three yeses," =================== */
const LAMP_X = [-1.2, 0, 1.2];
const LaunchBoard: React.FC<{ t: number; f: number; st: ("g" | "r" | "o")[]; labels: string[]; z?: number; x0?: number; pop?: number[] }> = ({ t, f, st, labels, z = -3.55, x0 = 0, pop = [0, 0, 0] }) => (<>
  <Box p={[x0, 4.4, z]} s={[4.0, 1.8, 0.25]} color="#22303a" />
  {LAMP_X.map((x, i) => { const c = st[i] === "g" ? "#36e07a" : st[i] === "r" ? "#ff3040" : "#3a4048"; const s = 1 + 0.35 * pop[i]; return <React.Fragment key={i}>
    <Cyl p={[x0 + x, 4.75, z + 0.14]} rt={0.42} h={0.08} rot={[Math.PI / 2, 0, 0]} color="#c9a24a" line={2} />
    <Ball p={[x0 + x, 4.75, z + 0.2]} r={0.3 * s} color={c} ink={0.04} />
    {st[i] !== "o" ? <Glow p={[x0 + x, 4.75, z + 0.5]} r={1.3 * s} color={st[i] === "g" ? "rgba(80,255,140,1)" : "rgba(255,50,60,1)"} o={0.7} /> : null}
    <CanvasPlane p={[x0 + x, 3.95, z + 0.14]} s={[1.05, 0.5]} px={[210, 100]} draw={(cc, W, H) => { cc.fillStyle = "#f4efe0"; cc.fillRect(0, 0, W, H); cc.strokeStyle = INK; cc.lineWidth = 6; cc.strokeRect(3, 3, W - 6, H - 6); const blink = labels[i] === "?" && Math.sin(f * 0.6) < 0; cc.fillStyle = st[i] === "r" ? "#d2202e" : st[i] === "g" ? "#118a44" : INK; cc.font = `900 ${labels[i].length > 5 ? 36 : 56}px Inter, Arial`; cc.textAlign = "center"; cc.textBaseline = "middle"; if (!blink) cc.fillText(labels[i], W / 2, H / 2 + 3); }} />
  </React.Fragment>; })}
  {void t}
</>);
const K7: Key[] = [
  { t: 24.75, pos: [1.0, 3.2, 1.3], look: [0.3, 2.1, -1.2], fov: 48 },
  { t: 26.3, pos: [0.9, 3.0, 1.8], look: [0.2, 1.9, -1.4], fov: 50 },
  { t: 27.3, pos: [0.5, 4.0, 3.4], look: [0.0, 3.2, -2.6], fov: 58 },
  { t: 28.3, pos: [0.8, 4.4, 3.5], look: [0.4, 3.9, -3.0], fov: 54 },
  { t: 29.1, pos: [1.4, 4.4, 2.6], look: [1.0, 4.1, -3.2], fov: 50 },
];
const S7 = ({ t, f }: Ctx) => {
  const u = clamp((t - 26.2) / 0.7), nod = 0.9 * Math.abs(Math.sin(u * Math.PI * 2)) * (u > 0 && u < 1 ? 1 : 0);
  const turn = seg(t, 26.3, 26.45, Easing.out(Easing.back(2))), reachK = seg(t, 25.9, 26.25);
  const three = t > 27.92;
  const st: ("g" | "r" | "o")[] = ["g", t > 26.3 ? "g" : "o", "o"];
  return (<>
    <Cam t={t} keys={K7} />
    <FogSet color="#06201e" near={5} far={22} />
    <L3 amb={1.5} kc="#c8fff0" />
    <HullRoom wall={["#2e7f7a", "#2a7470"]} floor={["#1d3a3a", "#193434"]} rib="#0f2424" />
    <Pipes colors={["#c9a24a", "#6a8a8a", "#e5233a", "#c9a24a"]} />
    <LaunchBoard t={t} f={f} st={st} labels={three ? ["YES", "YES", "?"] : ["1", "2", "3"]} pop={[0, hit(t, 26.3, 0.3), three ? hit(t, 27.95, 0.3) : 0]} />
    {/* console with three keys */}
    <Box p={[0, 0.6, -2.5]} s={[4.4, 1.2, 1.0]} color="#4a5a6a" /><Box p={[0, 1.27, -2.45]} s={[4.5, 0.14, 1.1]} color="#2b3a4a" rot={[0.12, 0, 0]} />
    {LAMP_X.map((x, i) => <group key={i} position={[x, 1.42, -2.3]}><Cyl p={[0, 0, 0]} rt={0.16} h={0.1} color="#c9a24a" line={2} /><Box p={[0, 0.14, 0]} s={[0.08, 0.24, 0.24]} rot={[0, i === 0 ? 1.4 : i === 1 ? 1.4 * turn : 0, 0]} color="#e8e0c8" line={2} /></group>)}
    <Cyl p={[2.9, 3.8, -1.4]} rt={0.28} h={7.6} color="#5a6a7a" /><Box p={[2.9, 2.6, -0.95]} s={[0.9, 0.5, 0.5]} color="#3a4a5a" />{[-1, 1].map((sd) => <Cyl key={sd} p={[2.9 + sd * 0.55, 2.6, -0.95]} rt={0.07} h={0.4} rot={[0, 0, Math.PI / 2]} color="#e5233a" line={2} />)}
    <Gauge p={[-3.0, 4.5, -3.55]} rot={[0, 0.3, 0]} v={0.4} label="DEPTH" /><Gauge p={[2.4, 5.7, -3.0]} rot={[0, -0.3, 0]} v={0.6} label="O2" r={0.36} red={0.0} />
    <Panel p={[-3.3, 2.4, -3.5]} s={[1.2, 1.6]} t={t} seed={6} color="#1f4a4a" />
    <CageLamp p={[0, 7.6, 0.5]} color="rgba(200,255,230,1)" /><CageLamp p={[-4.5, 7.6, 0]} color="rgba(200,255,230,1)" />
    <Dust t={t} area={[4, 6, 2]} color="rgba(200,255,240,.9)" />
    <P3 p={[-1.7, 0, -0.9]} h={3.4} look={capt} f={f} pose={{ mood: "angry", armR: [0.13, 0.4], nerv: 0.4, sweat: 0.8, lookX: 1 }} />
    <P3 p={[0.35, 0, -1.25]} h={3.3} look={polit} f={f} pose={{ mood: t < 26.6 ? "deadpan" : "angry", nod, armL: [-0.1, 0.4], armLK: reachK, lookX: t < 26.0 ? -1 : 0 }} />
  </>);
};

/* =================== S8 28.9 – 31.6  "and the third belongs to Vasili Arkhipov." =================== */
const K8: Key[] = [
  { t: 28.7, pos: [-4.4, 4.3, -1.0], look: [-6.3, 4.2, -3.2], fov: 44 },
  { t: 29.5, pos: [-4.2, 3.6, 0.8], look: [-8.5, 3.2, -1.6], fov: 50 },
  { t: 30.3, pos: [-4.0, 3.0, 2.2], look: [-11.0, 2.0, 0.0], fov: 52 },
  { t: 31.8, pos: [-6.2, 3.0, 1.7], look: [-10.2, 1.9, 0.1], fov: 50 },
];
const AX0 = -15.6, AX1 = -9.8, AW0 = 29.25, AW1 = 30.95;
const S8 = ({ t, f }: Ctx) => {
  const x = lerp(AX0, AX1, seg(t, AW0, AW1, Easing.inOut(Easing.sin))), moving = t > AW0 && t < AW1;
  const sill = Math.max(0, 1 - Math.abs(x + 12) / 0.55), hop = Math.sin(sill * Math.PI / 2) * 0.48;
  return (<>
    <Cam t={t} keys={K8} />
    <FogSet color="#06201e" near={6} far={26} />
    <L3 amb={1.5} kc="#c8fff0" />
    <HullRoom x0={-2} len={20} wall={["#2e7f7a", "#2a7470"]} floor={["#1d3a3a", "#193434"]} rib="#0f2424" />
    <HullRoom x0={-18} len={12} wall={["#d8a050", "#cc9548"]} floor={["#6a4a2a", "#5e4226"]} rib="#7a5020" />
    <Bulkhead x={-12} face={1} color="#3a6a66" hole={{ y: 1.95, rx: 0.95, ry: 1.55 }} />
    <group position={[-12 + 0.06, 1.95, 0.95]} rotation={[0, -1.9, 0]}><Ring p={[0, 0, -0.95]} R={1} r={0.08} s={[0.95, 1.55, 1]} rot={[0, Math.PI / 2, 0]} color="#c9a24a" /><mesh position={[0, 0, -0.95]} rotation={[0, Math.PI / 2, 0]} scale={[0.95, 1.55, 1]}><circleGeometry args={[1, 32]} /><meshToonMaterial color="#4a7a76" side={THREE.DoubleSide} /></mesh></group>
    <Glow p={[-15, 3.2, 0]} r={4} color="rgba(255,210,130,1)" o={0.6} /><CageLamp p={[-16, 7.6, 0]} color="rgba(255,220,150,1)" />
    <Pipes x0={-2} len={20} colors={["#c9a24a", "#6a8a8a", "#e5233a", "#c9a24a"]} />
    <LaunchBoard t={t} f={f} x0={-6.4} z={-3.6} st={["g", "g", "o"]} labels={["YES", "YES", t > 30.75 ? "ARKHIPOV" : "?"]} pop={[0, 0, hit(t, 30.75, 0.3)]} />
    <Gauge p={[-3.0, 4.4, -3.8]} v={0.4} label="DEPTH" /><Panel p={[-9.0, 3.4, -3.8]} s={[1.4, 1.4]} t={t} seed={9} color="#1f4a4a" />
    <Cabinet p={[-8.6, 0, 2.3]} w={1.4} color="#3a6a66" /><Valve p={[-10.6, 4.4, -3.4]} /><CageLamp p={[-7, 7.6, 0]} color="rgba(200,255,230,1)" />
    <Dust t={t} area={[3, 5, 2]} color="rgba(255,230,180,.9)" />
    <P3 p={[x, hop, 0.1]} sy={hop > 0.01 ? 0 : undefined} h={3.3} look={arkh} f={f} pose={{ mood: t < 30.9 ? "deadpan" : "deadpan", walk: moving ? (x - AX0) * WALK : undefined, speed: moving ? 0.75 : 0, air: hop > 0.05 ? 1 : 0, hunch: sill * 0.8, lookX: t > 30.9 ? 0.5 : 0, squash: t > AW1 && t < AW1 + 0.2 ? -0.06 : 0 }} />
  </>);
};

/* =================== S9 31.6 – 35.85  "He looks at a captain ready to die and drag the fleet above down with him." =================== */
const TBL: V3 = [0.6, 1.42, -1.2];
const SHIPS = [{ x: -0.2, z: -1.55, s0: 33.85 }, { x: 0.55, z: -1.05, s0: 34.0 }, { x: 1.3, z: -1.6, s0: 34.15 }];
const shipAt = (sh: { x: number; z: number; s0: number }, t: number) => {
  const dt = Math.max(0, t - sh.s0), vz = 2.4, edge = -0.4, tEdge = (edge - sh.z) / vz;
  if (dt <= tEdge) return { p: [sh.x + dt * 0.3, TBL[1] + 0.09, sh.z + dt * vz] as V3, rot: [0, 0.2 + dt * 1.5, 0] as V3, down: false };
  const q = dt - tEdge, y0 = TBL[1] + 0.09, tl = Math.sqrt(2 * (y0 - 0.09) / 20), qq = Math.min(q, tl);
  return { p: [sh.x + tEdge * 0.3 + qq * 0.4, y0 - 10 * qq * qq, edge + qq * vz] as V3, rot: q > tl ? [0, 0.2, 1.35] as V3 : [qq * 5, 0.2, qq * 7] as V3, down: q > tl };
};
const ToyFleet: React.FC<{ t: number }> = ({ t }) => (<>{SHIPS.map((sh, i) => { const s = shipAt(sh, t); return <group key={i} position={s.p} rotation={s.rot}><Destroyer p={[0, 0, 0]} s={0.075} num="" /></group>; })}</>);
const PlotTable: React.FC<{ f: number }> = ({ f }) => (<>
  <Box p={[TBL[0], TBL[1] - 0.07, TBL[2]]} s={[3.0, 0.14, 1.7]} color="#4a2a1a" />{[-1.3, 1.3].map((dx) => [-0.7, 0.7].map((dz) => <Box key={dx + "," + dz} p={[TBL[0] + dx, (TBL[1] - 0.14) / 2, TBL[2] + dz]} s={[0.14, TBL[1] - 0.14, 0.14]} color="#2b1a10" line={2} />))}
  <CanvasPlane p={[TBL[0], TBL[1] + 0.005, TBL[2]]} rot={[-Math.PI / 2, 0, 0]} s={[2.8, 1.55]} px={[560, 310]} draw={(c, W, H) => { c.fillStyle = "#1f6fb0"; c.fillRect(0, 0, W, H); c.strokeStyle = "rgba(255,255,255,.3)"; c.lineWidth = 2; for (let i = 1; i < 10; i++) { c.beginPath(); c.moveTo(i * W / 10, 0); c.lineTo(i * W / 10, H); c.stroke(); } for (let i = 1; i < 6; i++) { c.beginPath(); c.moveTo(0, i * H / 6); c.lineTo(W, i * H / 6); c.stroke(); } c.fillStyle = "#e8d8a8"; c.strokeStyle = INK; c.lineWidth = 4; c.beginPath(); c.ellipse(60, 60, 90, 60, 0.3, 0, 7); c.fill(); c.stroke(); c.fillStyle = "#ff3b3b"; c.beginPath(); c.arc(330 + Math.sin(f * 0.2) * 3, 170, 10, 0, 7); c.fill(); }} />
</>);
const LaunchLever: React.FC<{ p: V3; k: number }> = ({ p, k }) => (<group position={p}><Box p={[0, 0.75, 0]} s={[0.9, 1.5, 0.8]} color="#2b3350" /><Box p={[0, 1.52, 0.1]} s={[0.7, 0.06, 0.4]} color="#ffc23a" line={2} /><group position={[0, 1.55, 0.1]} rotation={[0, 0, -0.5 + 0.4 * k]}><Cyl p={[0, 0.35, 0]} rt={0.05} h={0.7} color="#8c92a8" line={2} /><Ball p={[0, 0.72, 0]} r={0.13} color="#e5233a" ink={0.03} /></group><CanvasPlane p={[0, 0.9, 0.41]} s={[0.7, 0.5]} px={[140, 100]} draw={(c, W, H) => drawTref(c, W, H)} /></group>);
const drawTref = (c: CanvasRenderingContext2D, W: number, H: number) => { c.fillStyle = "#ffd23a"; c.fillRect(0, 0, W, H); c.fillStyle = "#111"; const cx = W / 2, cy = H / 2, R = H * 0.42; for (let k = 0; k < 3; k++) { const a = -Math.PI / 2 + k * 2.094; c.beginPath(); c.moveTo(cx, cy); c.arc(cx, cy, R, a - 0.52, a + 0.52); c.closePath(); c.fill(); } c.fillStyle = "#ffd23a"; c.beginPath(); c.arc(cx, cy, R * 0.26, 0, 7); c.fill(); c.fillStyle = "#111"; c.beginPath(); c.arc(cx, cy, R * 0.16, 0, 7); c.fill(); };
const K9: Key[] = [
  { t: 31.4, pos: [-2.4, 3.3, 3.8], look: [0.6, 1.9, -2.4], fov: 54 },
  { t: 32.6, pos: [-1.8, 3.2, 3.4], look: [1.1, 2.0, -2.4], fov: 48 },
  { t: 33.7, pos: [-1.2, 3.5, 3.1], look: [1.6, 1.9, -2.2], fov: 46 },
  { t: 34.6, pos: [-0.6, 3.4, 3.2], look: [0.9, 1.0, -0.8], fov: 52 },
  { t: 36.05, pos: [-0.2, 2.9, 3.0], look: [0.8, 0.5, -0.2], fov: 54 },
];
const S9 = ({ t, f }: Ctx) => {
  const red = 0.5 + 0.5 * Math.sin(f * 0.4), grip = seg(t, 32.7, 32.95), sweep = seg(t, 33.75, 34.35, Easing.inOut(Easing.sin));
  return (<>
    <Cam t={t} keys={K9} fovKick={[32.81]} />
    <FogSet color="#200616" near={5} far={22} />
    <L3 amb={1.1 + 0.4 * red} kc="#ff9ab8" fc="#ff3060" />
    <HullRoom wall={["#6a2a5a", "#612652"]} floor={["#2a1a2a", "#241624"]} rib="#1a0a18" />
    <Pipes colors={["#c9a24a", "#6a4a6a", "#e5233a", "#c9a24a"]} />
    <PlotTable f={f} /><ToyFleet t={t} />
    <Glow p={[TBL[0], TBL[1] + 0.4, TBL[2]]} r={2.2} color="rgba(80,170,255,1)" o={0.35} />
    <LaunchLever p={[2.5, 0, -2.6]} k={grip} />
    <Gauge p={[-1.6, 4.6, -3.6]} v={0.7} label="DEPTH" /><Panel p={[-3.0, 2.8, -3.8]} s={[1.2, 1.6]} t={t} seed={13} color="#4a1a3a" /><Valve p={[3.8, 4.2, -3.5]} />
    <group position={[0.6, 7.45, -0.5]}><Cyl p={[0, 0, 0]} rt={0.25} h={0.3} color="#e5233a" line={2} /><Glow p={[Math.sin(f * 0.4) * 0.6, -0.4, Math.cos(f * 0.4) * 0.6]} r={2.4} color="rgba(255,40,80,1)" o={0.6} /></group>
    <Glow p={[0.8, 3.2, -2.6]} r={4.5} color="rgba(255,30,70,1)" o={0.12 * red} />
    <Dust t={t} area={[4, 6, 2]} color="rgba(255,200,230,.9)" />
    <P3 p={[0.9, 0, -2.55]} h={3.4} look={capt} f={f} pose={{ mood: t < 32.7 ? "angry" : t < 33.8 ? "grin" : "scream", nerv: t > 32.8 ? 0.75 : 0.35, sweat: 1,
      armR: [0.44, lerp(0.52, 0.6, grip)], armRK: Math.max(seg(t, 32.5, 32.8), 0.001), armL: [lerp(-0.3, 0.02, sweep), lerp(0.43, 0.36, sweep)], armLK: seg(t, 33.5, 33.75), lookX: t < 33.0 ? -0.8 : 0, hunch: 0.3 + sweep * 0.4 }} />
    <P3 p={[-1.7, 0, 1.0]} h={3.4} look={arkh} f={f} pose={{ mood: t < 34.0 ? "deadpan" : "worry", lookX: 1, nerv: 0.15 }} />
  </>);
};

/* =================== S10 35.85 – 39.3  "He says no. He argues. He calms him." =================== */
const K10: Key[] = [
  { t: 35.65, pos: [-3.0, 3.1, 3.4], look: [0.2, 1.9, -2.0], fov: 54 },
  { t: 37.0, pos: [-1.0, 3.0, 3.9], look: [0.3, 1.9, -2.0], fov: 52 },
  { t: 38.3, pos: [1.3, 3.1, 3.7], look: [0.4, 1.9, -2.0], fov: 50 },
  { t: 39.5, pos: [2.5, 3.3, 3.1], look: [0.5, 2.0, -2.1], fov: 50 },
];
const S10 = ({ t, f }: Ctx) => {
  const ax = lerp(-1.6, -0.25, seg(t, 35.85, 36.3, Easing.inOut(Easing.sin))), mv = t > 35.85 && t < 36.3;
  const calm = seg(t, 38.0, 38.4), release = seg(t, 38.35, 38.7), alarm = 1 - seg(t, 38.2, 38.8);
  const red = (0.5 + 0.5 * Math.sin(f * 0.4)) * alarm;
  const argue = t > 37.0 && t < 37.95, g = Math.sin((t - 37.0) * 9);
  const no = t > 36.3;
  return (<>
    <Cam t={t} keys={K10} />
    <FogSet color={colLerp("#200616", "#0a1a30", 1 - alarm)} near={5} far={22} />
    <L3 amb={1.0 + 0.4 * red + 0.5 * (1 - alarm)} kc={colLerp("#ff9ab8", "#ffe2c0", 1 - alarm)} fc="#9ab8ff" />
    <HullRoom wall={["#6a2a5a", "#612652"]} floor={["#2a1a2a", "#241624"]} rib="#1a0a18" />
    <Pipes colors={["#c9a24a", "#6a4a6a", "#e5233a", "#c9a24a"]} />
    <LaunchBoard t={t} f={f} x0={-1.6} z={-3.7} st={["g", "g", no ? "r" : "o"]} labels={["YES", "YES", no ? "NO" : "?"]} pop={[0, 0, hit(t, 36.36, 0.35)]} />
    <LaunchLever p={[2.3, 0, -2.4]} k={1 - release} />
    <PlotTable f={f} /><ToyFleet t={99} />
    <Valve p={[3.8, 4.2, -3.5]} /><Panel p={[3.2, 2.8, -3.9]} s={[1.0, 1.4]} t={t} seed={13} color="#4a1a3a" /><Gauge p={[1.2, 5.6, -3.3]} v={0.7} label="DEPTH" r={0.38} />
    <group position={[0.6, 7.45, -0.5]}><Cyl p={[0, 0, 0]} rt={0.25} h={0.3} color={alarm > 0.5 ? "#e5233a" : "#5a2a2a"} line={2} />{alarm > 0.05 ? <Glow p={[Math.sin(f * 0.4) * 0.6, -0.4, Math.cos(f * 0.4) * 0.6]} r={2.4} color="rgba(255,40,80,1)" o={0.6 * alarm} /> : null}</group>
    <CageLamp p={[-2.0, 7.6, 0]} on={1 - alarm * 0.7} color="rgba(255,225,170,1)" />
    <Dust t={t} area={[4, 6, 2]} color="rgba(255,220,220,.9)" />
    <P3 p={[1.25, 0, -2.3]} h={3.4} look={capt} f={f} pose={{ mood: t < 37.95 ? (argue && g > 0.3 ? "scream" : "angry") : t < 38.6 ? "worry" : "deadpan", nerv: lerp(0.7, 0.0, calm), sweat: 1 - calm, lookX: -1,
      armR: [0.31, 0.56], armRK: 1 - release, hunch: calm * 0.5, tilt: argue ? 0.04 * g : 0, nod: t > 38.7 ? 0.4 * hit(t, 38.7, 0.5) : 0 }} />
    <P3 p={[ax, 0, -1.9]} h={3.4} look={arkh} f={f} pose={{ mood: t < 36.3 ? "deadpan" : argue ? (g > 0 ? "angry" : "worry") : t < 38.0 ? "deadpan" : "smile", walk: mv ? (ax + 1.6) * WALK : undefined, speed: mv ? 0.7 : 0, lookX: 1,
      armR: t < 37.0 ? [0.3, 0.66] : argue ? [0.26 + 0.05 * g, 0.55 + 0.1 * Math.abs(g)] : [0.36, 0.55], armRK: seg(t, 36.15, 36.36, Easing.out(Easing.back(2))),
      armL: argue ? [-0.25, 0.5 + 0.08 * g] : [0.28, 0.53], armLK: argue ? 1 : calm, squash: hit(t, 36.3, 0.2) * 0.05 }} />
  </>);
};

/* =================== S11 39.3 – 43.3  "B-59 rises into daylight, and the Americans never learn" =================== */
const SUBP: V3 = [10, 0, 2];
const subY = (t: number) => t < 39.35 ? -10 : lerp(-10, 0.35, Easing.out(Easing.back(1.3))(clamp((t - 39.35) / 1.25))) + 0.12 * Math.sin(t * 1.8) * seg(t, 40.6, 41.4);
const K11: Key[] = [
  { t: 39.1, pos: [-3, 2.0, 32], look: [8, 3.5, 2], fov: 54 },
  { t: 40.4, pos: [-2, 2.6, 30], look: [8, 5.5, 2], fov: 54 },
  { t: 41.4, pos: [-6, 3.8, 22], look: [-6, 4, -10], fov: 56 },
  { t: 42.4, pos: [-7.5, 4.4, 12], look: [-10, 3.0, -24], fov: 50 },
  { t: 43.5, pos: [-8.2, 4.6, 8.5], look: [-10.5, 3.2, -25], fov: 46 },
];
const SPL = Array.from({ length: 34 }, (_, i) => ({ x: SUBP[0] - 9 + (i % 17) * 1.3, z: SUBP[2] + (i % 2 ? 3.4 : -3.4) + Math.sin(i * 2.3) * 0.8, vy: 7 + (i * 37 % 7), vx: Math.sin(i * 1.7) * 1.5, vz: (i % 2 ? 1 : -1) * (1.5 + (i % 3)), t0: 40.05 + (i % 5) * 0.05 }));
const S11 = ({ t, f }: Ctx) => {
  const y = subY(t), pitch = 0.3 * (1 - seg(t, 39.9, 41.2, Easing.out(Easing.cubic))), foam = seg(t, 40.1, 41.6);
  return (<>
    <Cam t={t} keys={K11} />
    <L3 amb={1.8} kc="#fff6e0" />
    <SkyDome top="#2f86e8" mid="#7cc0ff" bottom="#d8f0ff" />
    <Glow p={[60, 70, -150]} r={30} color="rgba(255,240,180,1)" o={0.9} /><Ball p={[60, 70, -152]} r={8} color="#fff4b0" ink={0} />
    {[[-60, 38, -150, 2.6], [20, 44, -170, 3.2], [-110, 30, -120, 2.2], [90, 32, -130, 2.4]].map(([x, yy, z, s], i) => <Cloud key={i} p={[x + t * 0.6, yy, z]} s={s} />)}
    <Sea t={t} />
    <Sub p={[SUBP[0], y, SUBP[2]]} rot={[0, 0, pitch]} t={t} />
    {t > 40.0 ? SPL.map((s, i) => { const d = t - s.t0; if (d < 0) return null; const yy = 0.2 + s.vy * d - 10 * d * d; return yy > -0.3 ? <Ball key={i} p={[s.x + s.vx * d, yy, s.z + s.vz * d]} r={0.32 + (i % 3) * 0.12} color="#ffffff" ink={0.04} /> : null; }) : null}
    {foam > 0 && foam < 1 ? <Ring p={[SUBP[0], 0.06, SUBP[2]]} R={9 + foam * 9} r={0.4} rot={[Math.PI / 2, 0, 0]} s={[1, 0.5, 1]} color="#ffffff" ink={0.04} /> : null}
    {t > 40.2 ? <Glow p={[SUBP[0], 1.5, SUBP[2] + 4]} r={10} color="rgba(255,255,255,1)" o={0.5 * (1 - foam)} /> : null}
    <Destroyer p={[-10, 0, -26]} rotY={0.25} s={1.6} num="850" />
    <Destroyer p={[30, 0, -60]} rotY={-0.4} s={1.6} num="827" />
    {[0, 1, 2].map((i) => { const P: V3 = [-13.5 + i * 2.2, 1.7, -24.2 + i * 0.55]; const bino = i === 1; return <React.Fragment key={i}>
      <P3 p={P} h={2.6} look={usN[i]} f={f + i * 7} pose={{ mood: t > 42.3 && i === 2 ? "smile" : "deadpan", lookX: 1, armR: bino ? [0.06, 0.62] : i === 2 && t > 42.6 ? undefined : undefined, armL: bino ? [-0.06, 0.62] : undefined, arms: i === 2 && t > 42.6 ? "shrug" : i === 0 ? "point" : "down", armK: i === 2 ? seg(t, 42.6, 42.85) : 1 }} />
      {bino ? <FaceGroup p={P}><Box p={hand(2.6, [0, 0.62], 0, false, 0.12)} s={[0.36, 0.16, 0.16]} color="#1b1b2a" line={2} /></FaceGroup> : null}</React.Fragment>; })}
  </>);
};

/* =================== S12 43.3 – 44.95  "what was waiting in that tube." =================== */
const K12: Key[] = [
  { t: 43.1, pos: [6.2, 2.7, 2.2], look: [11.9, 2.3, 0], fov: 50 },
  { t: 45.15, pos: [10.4, 2.35, 0.22], look: [12.8, 2.3, 0], fov: 38 },
];
const S12 = ({ t, f }: Ctx) => (<>
  <Cam t={t} keys={K12} />
  <FogSet color="#080c08" near={3} far={16} />
  <L3 amb={0.9} kc="#ffb0a0" />
  <HullRoom wall={["#2a3328", "#262e24"]} floor={["#1a1e18", "#161a14"]} rib="#121812" />
  <Bulkhead x={11.95} face={-1} color="#3a4436" hole={{ y: 2.3, rx: 0.75, ry: 0.75 }} />
  <mesh position={[15, 2.3, 0]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.75, 0.75, 6, 24, 1, true]} /><meshBasicMaterial color="#141a12" side={THREE.BackSide} /></mesh>
  {/* closed tube door with a real porthole */}
  <DoorPort p={[11.88, 2.3, 0]} />
  <Torpedo p={[15.8, 2.3, 0]} rot={[0, Math.PI, 0]} noseDecal />
  <Glow p={[12.7, 2.3, 0]} r={0.9} color="rgba(255,60,40,1)" o={0.45 + 0.25 * Math.sin(f * 0.25)} />
  <CanvasPlane p={[11.85, 3.4, 0]} rot={[0, -Math.PI / 2, 0]} s={[1.3, 0.42]} px={[260, 84]} frame="#2b3350" draw={(c, W, H) => { c.fillStyle = "#f4efe0"; c.fillRect(0, 0, W, H); c.fillStyle = INK; c.font = "900 50px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("TUBE 1", W / 2, H / 2 + 3); }} />
  <CanvasPlane p={[11.8, 1.45, 0.45]} rot={[0, -Math.PI / 2, 0.15 + Math.sin(f * 0.15) * 0.04]} s={[0.5, 0.3]} px={[120, 72]} draw={(c, W, H) => { c.fillStyle = "#e5233a"; c.fillRect(0, 0, W, H); c.fillStyle = "#fff"; c.font = "900 30px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("SPECIAL", W / 2, H / 2 + 2); }} />
  <Torpedo p={[7.0, 1.1, -2.2]} nuke={false} color="#4a5a3a" />
  <Pipes colors={["#8a7a3a", "#3a4a3a", "#7a2020", "#8a7a3a"]} />
  <CageLamp p={[8, 7.6, 0]} on={0.3} color="rgba(255,120,90,1)" />
  <Dust t={t} area={[3, 4, 2]} color="rgba(255,180,150,.8)" />
</>);
const DoorPort: React.FC<{ p: V3 }> = ({ p }) => {
  const geo = React.useMemo(() => { const s = new THREE.Shape(); s.absarc(0, 0, 0.8, 0, Math.PI * 2, false); const h = new THREE.Path(); h.absarc(0, 0, 0.3, 0, Math.PI * 2, true); s.holes.push(h); return new THREE.ShapeGeometry(s, 40); }, []);
  return (<group position={p} rotation={[0, -Math.PI / 2, 0]}>
    <mesh geometry={geo}><meshToonMaterial color="#5a6a52" side={THREE.DoubleSide} /></mesh>
    <Ring p={[0, 0, 0.02]} R={0.8} r={0.06} color="#c9a24a" /><Ring p={[0, 0, 0.02]} R={0.31} r={0.05} color="#c9a24a" />
    {[0, 1, 2, 3, 4, 5].map((i) => <Box key={i} p={[Math.cos(i * 1.047) * 0.6, Math.sin(i * 1.047) * 0.6, 0.05]} s={[0.14, 0.1, 0.1]} rot={[0, 0, i * 1.047]} color="#8c92a8" line={1} />)}
  </group>);
};

/* =================== S13 44.95 – 49.75  "Had he said yes, the first nuclear blast since Hiroshima would have gone off at sea," =================== */
const NUKE = 46.79, BC: V3 = [-6, -3, -72], WAVE = NUKE + 72 / 33;
const K13: Key[] = [
  { t: 44.75, pos: [2.4, 3.0, 6.0], look: [-2.0, 1.4, -40], fov: 52 },
  { t: 46.7, pos: [2.0, 3.1, 5.4], look: [-3.0, 1.6, -40], fov: 52 },
  { t: 47.6, pos: [2.6, 3.4, 6.6], look: [-4.0, 7.0, -50], fov: 58 },
  { t: 49.95, pos: [4.0, 5.2, 10.5], look: [-4.0, 10.0, -55], fov: 60 },
];
const S13 = ({ t, f }: Ctx) => {
  const k = seg(t, NUKE, NUKE + 3.0, Easing.out(Easing.quad)), wr = Math.max(0, t - NUKE) * 33;
  const rock = t > WAVE ? 0.06 * Math.exp(-(t - WAVE) * 1.8) * Math.sin((t - WAVE) * 6) : 0;
  const knock = seg(t, WAVE, WAVE + 0.3), sh = t > NUKE;
  const P: V3 = [1.5, 0, -0.4], dropT = NUKE + 0.12;
  const cam = camAt(dropT, K13).pos, rel = toWorld(P, hand(3.2, [0, 0.62], 0, false, 0.12), cam), dd = Math.max(0, t - dropT), tl = Math.sqrt(2 * (rel[1] - 0.1) / 20), q = Math.min(dd, tl);
  return (<>
    <Cam t={t} keys={K13} impacts={[[WAVE, 0.12]]} />
    <L3 amb={1.6} kc={sh ? "#ffe0b0" : "#ffb090"} />
    <group rotation={[0, 0, rock]}>
      <SkyDome top="#2a1f6e" mid="#8a3a8a" bottom="#ff9a5a" />
      <Sea y={-3} t={t} a="#1a4a8a" b="#3a6aa8" />
      <Ball p={[60, 6, -170]} r={10} color="#ffc070" ink={0} /><Glow p={[60, 6, -165]} r={36} color="rgba(255,160,80,1)" o={0.6} />
      <Destroyer p={[-34, -3, -66]} rotY={0.5} s={1.6} num="827" tilt={t > NUKE + 1.3 ? 0.12 * Math.exp(-(t - NUKE - 1.3)) * Math.sin((t - NUKE - 1.3) * 5) : 0} />
      <Destroyer p={[26, -3, -62]} rotY={-0.4} s={1.6} num="845" tilt={t > NUKE + 1.1 ? 0.12 * Math.exp(-(t - NUKE - 1.1)) * Math.sin((t - NUKE - 1.1) * 5) : 0} />
      {t < NUKE ? <Box p={[BC[0], BC[1] + 1.6, BC[2]]} s={[5, 3.2, 1.6]} color="#2b3640" /> : null}
      {sh ? <Mushroom p={BC} k={k} t={t} s={1.3} /> : null}
      {sh ? <Glow p={[BC[0], BC[1] + 8, BC[2] + 10]} r={50 * (0.4 + k)} color="rgba(255,190,120,1)" o={0.55 - 0.3 * k} /> : null}
      {sh && wr < 120 ? <Ring p={[BC[0], BC[1] + 0.1, BC[2]]} R={wr} r={0.6 + wr * 0.02} rot={[Math.PI / 2, 0, 0]} color="#ffffff" ink={0.1} /> : null}
    </group>
    {/* deck of the destroyer we stand on */}
    <Surface p={[0, 0, 2]} s={[14, 10]} rot={[-Math.PI / 2, 0, 0]} kind="plank" a="#8a8f9a" b="#7d828c" unit={1.4} />
    <Box p={[0, -1.5, 2]} s={[14, 3, 10]} color="#5a6474" />
    {[-1.5].map((z) => <React.Fragment key={z}>{Array.from({ length: 9 }, (_, i) => <Cyl key={i} p={[-6 + i * 1.5, 0.6, z]} rt={0.05} h={1.2} color="#c8ccd6" line={1} />)}<Cyl p={[0, 1.2, z]} rt={0.05} h={13} rot={[0, 0, Math.PI / 2]} color="#c8ccd6" line={1} /><Cyl p={[0, 0.7, z]} rt={0.04} h={13} rot={[0, 0, Math.PI / 2]} color="#c8ccd6" line={1} /></React.Fragment>)}
    <Ring p={[-2.8, 0.85, -1.45]} R={0.36} r={0.1} color="#ff6a3a" /><Box p={[4.4, 0.6, 0.6]} s={[1.8, 1.2, 1.6]} color="#7d8ca0" /><Cyl p={[4.4, 1.3, 1.6]} rt={0.08} h={1.6} rot={[Math.PI / 2, 0, 0]} color="#2b3350" line={1} />
    <Cyl p={[-4.6, 0.6, 1.0]} rt={0.35} h={1.2} color="#7d8ca0" /><Box p={[-3.2, 0.4, 2.2]} s={[1.0, 0.8, 0.8]} color="#8a6a3a" />
    <P3 p={P} h={3.2} look={usN[0]} f={f} pose={{ mood: !sh ? "deadpan" : t < WAVE ? "shock" : "shock", lookX: -1, nerv: sh ? 0.6 : 0, sweat: sh ? 1 : 0,
      armR: !sh ? [0.03, 0.62] : undefined, armL: !sh ? [-0.08, 0.62] : undefined, arms: sh ? "head" : "down", armK: seg(t, NUKE + 0.05, NUKE + 0.3), squash: hit(t, WAVE, 0.3) * -0.15, tilt: knock * 0.12 * (1 - seg(t, WAVE + 0.5, WAVE + 1.2)) }} />
    {!sh || t < dropT ? <FaceGroup p={P}><Box p={hand(3.2, [0, 0.62], 0, false, 0.12)} s={[0.42, 0.18, 0.18]} color="#1b1b2a" line={2} /></FaceGroup> : <Box p={[rel[0] - q * 0.4, Math.max(0.1, rel[1] - 10 * q * q), rel[2] + q * 0.6]} rot={[0, 0.3, dd > tl ? 0.2 : q * 6]} s={[0.42, 0.18, 0.18]} color="#1b1b2a" line={2} />}
    <P3 p={[-2.2, 0, 0.6]} h={3.1} look={usN[1]} f={f} pose={{ mood: sh ? "shock" : "smile", lookX: -0.6, arms: sh ? "up" : "down", armK: seg(t, NUKE + 0.1, NUKE + 0.35), nerv: sh ? 0.6 : 0, squash: hit(t, WAVE, 0.3) * -0.15 }} />
  </>);
};

/* =================== S14 49.75 – 53.1  "with no one on either side able to call it an accident." =================== */
const K14: Key[] = [
  { t: 49.55, pos: [-1.6, 3.0, 2.6], look: [-1.6, 2.0, -2.8], fov: 52 },
  { t: 50.8, pos: [0.0, 3.4, 4.2], look: [0.0, 2.4, -2.8], fov: 56 },
  { t: 51.4, pos: [1.6, 3.0, 2.8], look: [1.6, 2.0, -2.8], fov: 52 },
  { t: 52.2, pos: [0.0, 3.6, 6.4], look: [0.0, 2.6, -2.8], fov: 58 },
  { t: 53.3, pos: [0.0, 3.7, 6.0], look: [0.0, 2.8, -2.8], fov: 56 },
];
const PICK = 51.93;
const S14 = ({ t, f }: Ctx) => {
  const reach = seg(t, PICK - 0.25, PICK), lift = seg(t, PICK, PICK + 0.3, Easing.inOut(Easing.sin));
  const hd = (sd: number): [number, number] => [sd * lerp(0.21, 0.19, lift), lerp(0.4, 0.6, lift)];
  const sign = seg(t, 51.7, 52.1, Easing.out(Easing.back(1.5))), xk = seg(t, 52.45, 52.8);
  const ring = t > 51.2 && t < PICK ? Math.sin(f * 2.2) * 0.04 : 0;
  return (<>
    <Cam t={t} keys={K14} />
    <L3 amb={1.6} kc="#fff0e0" />
    <Surface p={[-5, 0, 0]} s={[10, 14]} rot={[-Math.PI / 2, 0, 0]} kind="carpet" a="#1d3a8a" b="#1a347c" unit={1.6} />
    <Surface p={[5, 0, 0]} s={[10, 14]} rot={[-Math.PI / 2, 0, 0]} kind="carpet" a="#a3182a" b="#931524" unit={1.6} />
    <Box p={[0, 0.02, 0]} s={[0.12, 0.04, 14]} color="#0b0d1a" line={1} />
    <CanvasPlane p={[-3.5, 4.5, -4.5]} s={[7, 9]} px={[350, 450]} draw={(c, W, H) => { for (let i = 0; i < 13; i++) { c.fillStyle = i % 2 ? "#f4f4f4" : "#c8202e"; c.fillRect(0, i * H / 13, W, H / 13 + 1); } c.fillStyle = "#1d3a8a"; c.fillRect(0, 0, W * 0.5, H * 0.42); c.fillStyle = "#fff"; for (let y = 0; y < 6; y++) for (let x = 0; x < 5; x++) { c.beginPath(); c.arc(18 + x * 32 + (y % 2) * 14, 18 + y * 30, 6, 0, 7); c.fill(); } }} />
    <CanvasPlane p={[3.5, 4.5, -4.5]} s={[7, 9]} px={[350, 450]} draw={(c, W, H) => { c.fillStyle = "#b3122e"; c.fillRect(0, 0, W, H); c.fillStyle = "#ffc23a"; c.save(); c.translate(W * 0.7, H * 0.2); c.beginPath(); for (let i = 0; i < 10; i++) { const r = i % 2 ? 18 : 44, a = -Math.PI / 2 + i * Math.PI / 5; c.lineTo(Math.cos(a) * r, Math.sin(a) * r); } c.closePath(); c.fill(); c.restore(); }} />
    <Box p={[0, 4.5, -4.45]} s={[0.25, 9, 0.2]} color="#0b0d1a" />
    {[["WASHINGTON", -2.6, -0.4], ["MOSCOW", 2.6, 0.9]].map(([lab, x, off]) => <React.Fragment key={lab as string}><Ball p={[x as number, 6.6, -4.3]} r={0.55} color="#f4efe0" ink={0.06} /><CanvasPlane p={[x as number, 6.6, -3.7]} s={[1.0, 1.0]} px={[120, 120]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 6; c.lineCap = "round"; const a1 = t * 0.4 + (off as number), a2 = t * 4; c.beginPath(); c.moveTo(W / 2, H / 2); c.lineTo(W / 2 + Math.sin(a1) * 26, H / 2 - Math.cos(a1) * 26); c.moveTo(W / 2, H / 2); c.lineTo(W / 2 + Math.sin(a2) * 40, H / 2 - Math.cos(a2) * 40); c.stroke(); }} /><CanvasPlane p={[x as number, 5.75, -4.3]} s={[1.8, 0.4]} px={[360, 80]} draw={(c, W, H) => { c.fillStyle = "#0b0d1a"; c.fillRect(0, 0, W, H); c.fillStyle = "#fff"; c.font = "900 46px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(lab as string, W / 2, H / 2 + 2); }} /></React.Fragment>)}
    {/* two desks */}
    {[-1, 1].map((sd) => <Desk key={sd} p={[sd * 2.0, 0, -1.9]} w={2.6} d={1.4} top={sd < 0 ? "#c9d6f0" : "#f0c9c9"} leg={sd < 0 ? "#5a7ac8" : "#c85a5a"} />)}
    {/* the sign that never gets to say ACCIDENT */}
    {[-1.3, 1.3].map((x) => <Cyl key={x} p={[x, 8.5 - (2.2 * sign + 0.6) / 2, -2.2]} rt={0.03} h={2.2 * sign + 0.6} color="#2b3350" line={1} />)}
    <CanvasPlane p={[0, 9.6 - 2.2 * sign - 1.5, -2.2]} s={[3.2, 1.0]} px={[640, 200]} frame="#2b3350" draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = INK; c.font = "900 104px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("ACCIDENT", W / 2, H / 2 + 6); c.strokeStyle = "#e5233a"; c.lineWidth = 26; c.lineCap = "round"; const a = clamp(xk * 2), b = clamp(xk * 2 - 1); c.beginPath(); c.moveTo(60, 30); c.lineTo(60 + (W - 120) * a, 30 + (H - 60) * a); c.stroke(); if (b > 0) { c.beginPath(); c.moveTo(W - 60, 30); c.lineTo(W - 60 - (W - 120) * b, 30 + (H - 60) * b); c.stroke(); } }} />
    {/* officers with hotline phones (handset glued to the hand) */}
    {([[-2.2, usOff, 1], [2.2, suOff, -1]] as [number, Look, number][]).map(([x, lk, sd]) => { const P: V3 = [x, 0, -2.9], tgt = hd(sd); return <React.Fragment key={x}>
      <P3 p={P} h={3.3} look={lk} f={f + (sd > 0 ? 0 : 11)} pose={{ mood: t < 50.0 ? "deadpan" : t < 52.4 ? "worry" : "scream", lookX: sd, nerv: t > 51.3 ? 0.6 : 0.2, sweat: t > 50.5 ? 0.8 : 0, armR: sd > 0 ? tgt : undefined, armL: sd < 0 ? tgt : undefined, armRK: sd > 0 ? Math.max(reach, lift) : 1, armLK: sd < 0 ? Math.max(reach, lift) : 1, squash: hit(t, 52.4, 0.25) * 0.06, flip: false }} />
      <FaceGroup p={P}>
        <PhoneBase p={[sd * 0.21 * 3.3, 1.02, 0.55]} />
        <Handset p={lift > 0.02 ? hand(3.3, tgt, 0, false, 0.6).map((v, j) => (j === 0 ? sd * Math.abs(v) : v)) as V3 : [sd * 0.21 * 3.3, 1.32 + ring, 0.62]} rot={lift > 0.02 ? [0, 0, sd * 0.3] : [0, 0, Math.PI / 2]} />
      </FaceGroup></React.Fragment>; })}
  </>);
};

/* =================== S15 53.1 – 58.58  "One man's no stood between October 1962 and everything after it." =================== */
const GC: V3 = [0, -6, -2], GRR = 6;
const K15: Key[] = [
  { t: 52.9, pos: [0.4, 2.4, 3.4], look: [0, 1.4, -2], fov: 50 },
  { t: 54.6, pos: [-1.4, 2.8, 4.6], look: [-1.0, 1.8, -2.4], fov: 52 },
  { t: 55.8, pos: [-1.4, 3.0, 5.0], look: [-1.8, 2.2, -3.0], fov: 50 },
  { t: 57.3, pos: [1.2, 4.2, 9.5], look: [0.6, 1.2, -2], fov: 56 },
  { t: 58.8, pos: [2.5, 6.0, 24], look: [0, -2.0, -2], fov: 58 },
];
const YEARS = [1963, 1969, 1975, 1981, 1986, 1989, 1991, 1997, 2001, 2004, 2008, 2012, 2016, 2020, 2024, 2026];
const PAD: V3 = [-2.3, 0, -2.9];
const S15 = ({ t, f }: Ctx) => {
  const circ = seg(t, 55.75, 56.4), dawn = seg(t, 56.8, 58.6);
  const city = Array.from({ length: 40 }, (_, i) => { const th = (i * 2.39996) % (Math.PI * 2), ph = 0.35 + ((i * 0.618) % 1) * 1.2; return { p: [GC[0] + Math.sin(ph) * Math.cos(th) * (GRR + 0.05), GC[1] + Math.cos(ph) * (GRR + 0.05), GC[2] + Math.sin(ph) * Math.sin(th) * (GRR + 0.05)] as V3, on: seg(t, 57.4 + i * 0.03, 57.6 + i * 0.03) }; });
  return (<>
    <Cam t={t} keys={K15} />
    <L3 amb={1.6} kc="#ffe0b0" />
    <SkyDome top="#070a2a" mid="#1a1a5a" bottom="#3a2a7a" stars={260} />
    <Glow p={[14, -5, -30]} r={30 * (0.5 + dawn)} color="rgba(255,170,90,1)" o={0.25 + 0.5 * dawn} />
    <Globe p={GC} r={GRR} rotY={0.6 + t * 0.03} tilt={0.1} />
    <Glow p={[GC[0], GC[1], GC[2] + 3]} r={10} color="rgba(90,160,255,1)" o={0.25} />
    {city.map((c, i) => c.on > 0 ? <Glow key={i} p={c.p} r={0.5 * c.on} color="rgba(255,220,120,1)" o={0.95} /> : null)}
    {/* the calendar on its stand */}
    {[-0.8, 0.8].map((dx) => <Cyl key={dx} p={[PAD[0] + dx, 0.6, PAD[2]]} rt={0.06} h={2.6} color="#5a3420" line={2} />)}
    <CanvasPlane p={[PAD[0], 2.6, PAD[2] + 0.05]} s={[2.0, 2.3]} px={[400, 460]} frame={INK} draw={(c, W, H) => {
      c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = "#e23b3b"; c.fillRect(0, 0, W, 120); c.fillStyle = "#fff"; c.font = "900 64px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("OCTOBER", W / 2, 62);
      c.fillStyle = INK; c.font = "900 150px Inter, Arial"; c.fillText("1962", W / 2, 280); c.font = "800 40px Inter, Arial"; c.fillStyle = "#555"; c.fillText("SAT 27", W / 2, 400);
      if (circ > 0) { c.strokeStyle = "#e23b3b"; c.lineWidth = 12; c.beginPath(); c.ellipse(W / 2, 280, 185, 95, -0.05, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * circ); c.stroke(); }
    }} />
    {/* everything after: pages fly out into the future */}
    {YEARS.map((y, i) => { const t0 = 57.35 + i * 0.07, d = t - t0; if (d < 0) return null; const a = d * 1.7 + i * 0.3, R = 1.5 + d * 3.2;
      const p: V3 = [PAD[0] + 0.6 + Math.cos(a) * R * 0.9 + d * 2.4, 2.6 + d * 1.6 + Math.sin(a * 1.3) * 0.6, PAD[2] + Math.sin(a) * R * 0.6];
      return <CanvasPlane key={y} p={p} rot={[Math.sin(d * 3 + i) * 0.5, d * 2 + i, Math.sin(d * 2) * 0.4]} s={[1.0, 1.15]} px={[160, 184]} draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = "#2f8cff"; c.fillRect(0, 0, W, 44); c.strokeStyle = INK; c.lineWidth = 6; c.strokeRect(3, 3, W - 6, H - 6); c.fillStyle = INK; c.font = "900 50px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(String(y), W / 2, 112); }} />; })}
    <P3 p={[0.2, 0, -2]} h={3.3} look={arkh} f={f} pose={{ mood: t < 54.4 ? "deadpan" : "smile", lookX: t > 57.4 ? 1 : t > 55.0 && t < 56.8 ? -0.8 : 0, arms: "down" }} />
  </>);
};

/* =================== composition =================== */
const CUTS = [0, 3.0, 8.4, 12.75, 15.95, 21.55, 24.95, 28.9, 31.6, 35.85, 39.3, 43.3, 44.95, 49.75, 53.1, 58.6];
const TINT = ["rgba(40,200,120,.06)", "rgba(255,90,30,.09)", "rgba(20,120,220,.07)", "rgba(40,100,220,.07)", "rgba(255,150,40,.07)", "rgba(255,30,30,.10)", "rgba(20,200,170,.06)", "rgba(20,200,170,.05)", "rgba(220,30,120,.08)", "rgba(200,60,120,.05)", "rgba(255,220,140,.04)", "rgba(255,40,20,.07)", "rgba(255,120,60,.07)", "rgba(120,60,200,.05)", "rgba(60,40,200,.08)"];
export const B59: React.FC = () => {
  const f = useCurrentFrame(), t = f / FPS;
  const si = Math.max(0, CUTS.findIndex((c, i) => t >= c && t < CUTS[i + 1]));
  const nukeFlash = t > NUKE ? 1 - seg(t, NUKE + 0.05, NUKE + 0.7) : 0;
  const S = [S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11, S12, S13, S14, S15];
  const TR: Trans[] = ["ghost", "zoom", "whip", "flash", "ghost", "flash", "ghost", "whip", "ghost", "ghost", "zoom", "ghost", "flash", "whip", "ghost"];
  const BG = ["#06385a", "#3a1206", "#0a4a78", "#0c1e3a", "#2a1606", "#2a0606", "#06201e", "#06201e", "#200616", "#200616", "#7cc0ff", "#080c08", "#2a1f6e", "#1a1a2a", "#070a2a"];
  return (
    <AbsoluteFill style={{ background: "#000" }}>
      <Audio src={staticFile("mix.wav")} />
      {S.map((Comp, i) => <Scene key={i} first={i === 0} start={CUTS[i]} end={CUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <Comp {...c} />}</Scene>)}
      <Grade t={t} shaft={false} tint={TINT[si]} />
      {nukeFlash > 0 ? <AbsoluteFill style={{ background: "#fff8e8", opacity: nukeFlash }} /> : null}
      <Captions />
    </AbsoluteFill>
  );
};
