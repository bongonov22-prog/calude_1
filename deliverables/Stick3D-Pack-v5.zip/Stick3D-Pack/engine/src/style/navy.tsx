// Navy / submarine kit (first used in videos/B59.tsx). Logged in rules/ACTION-LIBRARY.md.
// Puppet3D (puppet that can ROLL to the floor: faint/fall), FogSet, Ring, HullRoom (cylindrical pressure hull interior),
// Bulkhead (with a real hatch hole), Sub (exterior), Destroyer, DepthCharge, Torpedo (+ nuclear decal), Gauge, Thermo,
// ShipBell, Sea, SurfaceBelow, SkyDome, Mushroom, PhoneBase, Handset, Cloud.
import React, { useMemo, useRef, useLayoutEffect } from "react";
import * as THREE from "three";
import { useThree } from "@react-three/fiber";
import { Box, Cyl, Ball, CanvasPlane, Shadow, Surface, patternTex, INK } from "./toon";
import { drawPuppet, Look, Pose } from "./puppet";
import { V3, clamp, lerp } from "./kit";
import { Glow } from "./props";
import { Extrude } from "./extra";

const ramp = (() => { const d = new Uint8Array([90, 170, 255]); const t = new THREE.DataTexture(d, 3, 1, THREE.RedFormat); t.minFilter = t.magFilter = THREE.NearestFilter; t.needsUpdate = true; return t; })();

/* ---------- puppet that can roll (faint / fall / lie in a bunk). Pivot = feet. roll>0 => head goes screen-left ---------- */
export const Puppet3D: React.FC<{ p: V3; h: number; look: Look; pose: Omit<Pose, "t"> & { t?: number }; f: number; roll?: number; shadow?: boolean; sy?: number }> = ({ p, h, look, pose, f, roll = 0, shadow = true, sy }) => {
  const { camera } = useThree();
  const W = 512, H = 768;
  const { cv, tex } = useMemo(() => { const cv = document.createElement("canvas"); cv.width = W; cv.height = H; const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 4; return { cv, tex }; }, []);
  drawPuppet(cv.getContext("2d")!, W, H, look, { ...pose, t: pose.t ?? f }); tex.needsUpdate = true;
  const ref = useRef<THREE.Group>(null);
  const lift = Math.abs(Math.sin(roll)) * 0.17 * h; // lying body rests ON the floor, not half inside it
  useLayoutEffect(() => { if (ref.current) ref.current.rotation.set(0, Math.atan2(camera.position.x - p[0], camera.position.z - p[2]), roll); });
  const yaw = Math.atan2(camera.position.x - p[0], camera.position.z - p[2]), off = -Math.sin(roll) * h * 0.34;
  return (<>
    {shadow ? <Shadow p={[p[0] + off * Math.cos(yaw), sy ?? p[1], p[2] - off * Math.sin(yaw)]} r={h * (0.32 + Math.abs(Math.sin(roll)) * 0.3)} /> : null}
    <group ref={ref} position={[p[0], p[1] + lift, p[2]]}><mesh position={[0, h * 0.483, 0]}><planeGeometry args={[h * W / H, h]} /><meshBasicMaterial map={tex} transparent alphaTest={0.02} /></mesh></group>
  </>);
};

export const FogSet: React.FC<{ color: string; near: number; far: number }> = ({ color, near, far }) => {
  const { scene } = useThree();
  const fog = useMemo(() => new THREE.Fog(color, near, far), []);
  fog.color.set(color); fog.near = near; fog.far = far; scene.fog = fog;
  return null;
};

export const Ring: React.FC<{ p: V3; R: number; r: number; color: string; rot?: V3; arc?: number; ink?: number; s?: V3 }> = ({ p, R, r, color, rot, arc = Math.PI * 2, ink = 0.035, s }) => (
  <group position={p} rotation={rot} scale={s}>
    <mesh><torusGeometry args={[R, r, 10, 56, arc]} /><meshToonMaterial color={color} gradientMap={ramp} /></mesh>
    {ink > 0 ? <mesh><torusGeometry args={[R, r + ink, 10, 56, arc]} /><meshBasicMaterial color={INK} side={THREE.BackSide} /></mesh> : null}
  </group>
);

/* ---------- pressure-hull interior: axis along x, floor at y=0 ---------- */
export const HC = 3.2, HR = 4.5, FW = Math.sqrt(HR * HR - HC * HC);
export const HullRoom: React.FC<{ x0?: number; len?: number; wall: [string, string]; floor: [string, string]; rib: string; ribColor?: (x: number) => string; kind?: "tile" | "wood" | "brick" | "plank"; caps?: [string | null, string | null] }> = ({ x0 = 0, len = 24, wall, floor, rib, ribColor, kind = "tile", caps = [null, null] }) => {
  const tex = patternTex(kind, wall[0], wall[1], [Math.round((2 * Math.PI * HR) / 1.7), Math.round(len / 1.7)]);
  const ribs: number[] = []; for (let x = x0 - len / 2 + 1.2; x < x0 + len / 2 - 0.5; x += 2.4) ribs.push(x);
  return (<>
    <mesh position={[x0, HC, 0]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[HR, HR, len, 48, 1, true]} /><meshBasicMaterial map={tex} side={THREE.BackSide} /></mesh>
    <Surface p={[x0, 0.01, 0]} s={[len, FW * 2]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a={floor[0]} b={floor[1]} unit={1.1} />
    {[-1, 1].map((sd) => <Box key={sd} p={[x0, 0.12, sd * (FW - 0.12)]} s={[len, 0.24, 0.24]} color={rib} line={2} />)}
    {ribs.map((x) => <Ring key={x} p={[x, HC, 0]} R={HR - 0.12} r={0.13} color={ribColor ? ribColor(x) : rib} rot={[0, Math.PI / 2, 0]} ink={0.03} />)}
    {caps[0] ? <mesh position={[x0 - len / 2, HC, 0]} rotation={[0, Math.PI / 2, 0]}><circleGeometry args={[HR, 48]} /><meshToonMaterial color={caps[0]} gradientMap={ramp} /></mesh> : null}
    {caps[1] ? <mesh position={[x0 + len / 2, HC, 0]} rotation={[0, -Math.PI / 2, 0]}><circleGeometry args={[HR, 48]} /><meshToonMaterial color={caps[1]} gradientMap={ramp} /></mesh> : null}
  </>);
};
// Bulkhead disk at x with an optional real hatch hole (ellipse centre y, half sizes rx/ry); face=+1 faces +x
export const Bulkhead: React.FC<{ x: number; color: string; face?: 1 | -1; hole?: { y: number; rx: number; ry: number; z?: number }; rim?: string }> = ({ x, color, face = 1, hole, rim = "#c9a24a" }) => {
  const geo = useMemo(() => { const s = new THREE.Shape(); s.absarc(0, 0, HR, 0, Math.PI * 2, false); if (hole) { const h = new THREE.Path(); h.absellipse(-(hole.z ?? 0) * face, hole.y - HC, hole.rx, hole.ry, 0, Math.PI * 2, true, 0); s.holes.push(h); } return new THREE.ShapeGeometry(s, 48); }, [hole?.y, hole?.rx, hole?.ry, face]);
  return (<group position={[x, HC, 0]} rotation={[0, face * Math.PI / 2, 0]}>
    <mesh geometry={geo}><meshToonMaterial color={color} gradientMap={ramp} side={THREE.DoubleSide} /></mesh>
    {hole ? <Ring p={[-(hole.z ?? 0) * face, hole.y - HC, 0.03]} R={1} r={0.09} s={[hole.rx + 0.05, hole.ry + 0.05, 1]} color={rim} ink={0.02} /> : null}
  </group>);
};

/* ---------- submarine exterior (hull axis x, centre at p) ---------- */
export const Sub: React.FC<{ p: V3; rot?: V3; r?: number; L?: number; color?: string; label?: string; t?: number }> = ({ p, rot, r = HR, L = 24, color = "#3a4856", label = "B-59", t = 0 }) => {
  const sx = L * 0.1;
  return (<group position={p} rotation={rot}>
    <Cyl p={[0, 0, 0]} rt={r} h={L} color={color} rot={[0, 0, Math.PI / 2]} line={3} />
    <Ball p={[L / 2, 0, 0]} r={r} s={[1.9, 1, 1]} color={color} ink={0.12} />
    <Cyl p={[-L / 2 - 3, 0, 0]} rt={0.5} rb={r} h={6} color={color} rot={[0, 0, Math.PI / 2]} line={3} />
    <Box p={[0, r - 0.02, 0]} s={[L * 0.86, 0.26, 2.0]} color="#4c5b6a" line={3} />
    <Box p={[sx, r + 1.6, 0]} s={[7, 3.4, 2.1]} color={color} />
    <Box p={[sx + 0.5, r + 3.45, 0]} s={[5.4, 0.4, 1.9]} color="#28323c" />
    <Cyl p={[sx - 0.8, r + 4.6, 0]} rt={0.13} h={2.2} color="#28323c" line={2} /><Cyl p={[sx + 0.7, r + 4.3, 0]} rt={0.1} h={1.6} color="#28323c" line={2} />
    {[1, -1].map((sd) => <CanvasPlane key={sd} p={[sx, r + 1.7, sd * 1.07]} rot={[0, sd > 0 ? 0 : Math.PI, 0]} s={[4.6, 1.5]} px={[460, 150]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.fillStyle = "#f4f1e6"; c.font = "900 132px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(label, W / 2, H / 2 + 6); }} />)}
    {[1, -1].map((sd) => <Box key={"dp" + sd} p={[L / 2 - 1.5, -0.4, sd * (r + 0.7)]} s={[1.6, 0.14, 1.6]} color="#28323c" line={2} />)}
    {[1, -1].map((sd) => <Box key={"sp" + sd} p={[-L / 2 - 3.6, 0, sd * 1.7]} s={[1.8, 0.14, 2.6]} color="#28323c" line={2} />)}
    <Box p={[-L / 2 - 3.6, 0, 0]} s={[1.8, 3.2, 0.14]} color="#28323c" line={2} />
    <group position={[-L / 2 - 6.15, 0, 0]} rotation={[t * 9, 0, 0]}>{[0, 1, 2].map((i) => <Box key={i} p={[0, Math.cos(i * 2.094) * 0.7, Math.sin(i * 2.094) * 0.7]} rot={[i * 2.094, 0, 0]} s={[0.12, 1.4, 0.4]} color="#c9a24a" line={2} />)}</group>
  </group>);
};

/* ---------- destroyer (waterline y=0, deck y=1.05, length ~15) ---------- */
export const Destroyer: React.FC<{ p: V3; rotY?: number; s?: number; hull?: string; top?: string; num?: string; tilt?: number; pitch?: number }> = ({ p, rotY = 0, s = 1, hull = "#7d8ca0", top = "#a9b8cc", num = "850", tilt = 0, pitch = 0 }) => (
  <group position={p} rotation={[pitch, rotY, tilt]} scale={s}>
    <Extrude pts={[[-7, -1.2], [6, -1.2], [7.6, 1.0], [-7.2, 1.0]]} depth={2.4} color={hull} line={4} />
    <Box p={[0, 1.05, 0]} s={[14.2, 0.1, 2.3]} color="#8a7a66" line={2} />
    <Box p={[-0.3, -1.22, 0]} s={[12.8, 0.08, 2.0]} color="#b8302a" line={2} /><Box p={[0, -1.3, 0]} s={[11, 0.18, 0.2]} color="#5a6474" line={2} />
    {[0.6, -0.6].map((z) => <group key={z} position={[-6.4, -0.95, z]} rotation={[0, 0, 0]}>{[0, 1, 2].map((i) => <Box key={i} p={[0, Math.cos(i * 2.094) * 0.28, Math.sin(i * 2.094) * 0.28]} rot={[i * 2.094, 0, 0]} s={[0.08, 0.55, 0.2]} color="#c9a24a" line={2} />)}</group>)}
    <Box p={[-6.9, -0.8, 0]} s={[0.6, 0.8, 0.08]} color="#5a6474" line={2} />
    <Box p={[2.0, 1.8, 0]} s={[2.6, 1.4, 1.7]} color={top} /><Box p={[2.3, 2.85, 0]} s={[1.6, 0.7, 1.5]} color={top} /><Box p={[3.12, 2.9, 0]} s={[0.04, 0.26, 1.3]} color="#1b2a44" line={1} />
    <Cyl p={[0.1, 2.3, 0]} rt={0.36} rb={0.46} h={1.8} color="#2b3350" /><Cyl p={[-1.5, 2.2, 0]} rt={0.36} rb={0.46} h={1.6} color="#2b3350" />
    <Cyl p={[2.6, 4.3, 0]} rt={0.06} h={2.6} color="#2b3350" line={1} /><Box p={[2.6, 5.0, 0]} s={[0.08, 0.08, 1.5]} color="#2b3350" line={1} />
    <Box p={[5.0, 1.45, 0]} s={[1.0, 0.6, 1.0]} color={top} /><Cyl p={[5.9, 1.5, 0]} rt={0.07} h={1.4} rot={[0, 0, Math.PI / 2]} color="#2b3350" line={1} />
    <Box p={[-4.4, 1.45, 0]} s={[1.2, 0.6, 1.0]} color={top} /><Cyl p={[-5.3, 1.5, 0]} rt={0.07} h={1.2} rot={[0, 0, Math.PI / 2]} color="#2b3350" line={1} />
    {[1, -1].map((sd) => <Box key={sd} p={[-6.3, 1.35, sd * 0.7]} s={[1.0, 0.5, 0.42]} color="#2b3350" line={2} />)}
    {[1, -1].map((sd) => <CanvasPlane key={"n" + sd} p={[5.0, 0.25, sd * 1.22]} rot={[0, sd > 0 ? 0 : Math.PI, 0]} s={[1.6, 0.7]} px={[160, 70]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.fillStyle = "#fff"; c.font = "900 60px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(num, W / 2, H / 2 + 3); }} />)}
  </group>
);
export const DepthCharge: React.FC<{ p: V3; rot?: V3; s?: number }> = ({ p, rot, s = 1 }) => (
  <group position={p} rotation={rot} scale={s}><Cyl p={[0, 0, 0]} rt={0.34} h={0.8} color="#2b3350" /><Cyl p={[0, 0.18, 0]} rt={0.355} h={0.1} color="#ffc23a" line={2} /><Cyl p={[0, -0.18, 0]} rt={0.355} h={0.1} color="#ffc23a" line={2} /></group>
);

/* ---------- radiation trefoil ---------- */
export const drawTrefoil = (c: CanvasRenderingContext2D, W: number, H: number, bg = "#ffd23a") => {
  c.clearRect(0, 0, W, H); const cx = W / 2, cy = H / 2, R = W / 2 - 4;
  c.fillStyle = bg; c.beginPath(); c.arc(cx, cy, R, 0, 7); c.fill(); c.strokeStyle = INK; c.lineWidth = W * 0.04; c.stroke();
  c.fillStyle = "#111";
  for (let k = 0; k < 3; k++) { const a = -Math.PI / 2 + k * (Math.PI * 2 / 3); c.beginPath(); c.moveTo(cx, cy); c.arc(cx, cy, R * 0.82, a - Math.PI / 6, a + Math.PI / 6); c.closePath(); c.fill(); }
  c.fillStyle = bg; c.beginPath(); c.arc(cx, cy, R * 0.24, 0, 7); c.fill(); c.fillStyle = "#111"; c.beginPath(); c.arc(cx, cy, R * 0.15, 0, 7); c.fill();
};
export const Torpedo: React.FC<{ p: V3; L?: number; r?: number; rot?: V3; color?: string; nuke?: boolean; noseDecal?: boolean }> = ({ p, L = 5, r = 0.36, rot, color = "#55663f", nuke = true, noseDecal }) => (
  <group position={p} rotation={rot}>
    <Cyl p={[0, 0, 0]} rt={r} h={L} color={color} rot={[0, 0, Math.PI / 2]} />
    <Ball p={[L / 2, 0, 0]} r={r} s={[1.8, 1, 1]} color={nuke ? "#ffc23a" : color} ink={0.04} />
    <Cyl p={[-L / 2 - 0.4, 0, 0]} rt={0.12} rb={r} h={0.8} rot={[0, 0, Math.PI / 2]} color={color} />
    <Box p={[-L / 2 - 0.55, 0, 0]} s={[0.5, 1.0, 0.05]} color="#2b3350" line={2} /><Box p={[-L / 2 - 0.55, 0, 0]} s={[0.5, 0.05, 1.0]} color="#2b3350" line={2} />
    {nuke ? <>
      <Cyl p={[L / 2 - 0.5, 0, 0]} rt={r + 0.012} h={0.22} rot={[0, 0, Math.PI / 2]} color="#e5233a" line={2} />
      {[1, -1].map((sd) => <CanvasPlane key={sd} p={[0.5, 0, sd * (r + 0.02)]} rot={[0, sd > 0 ? 0 : Math.PI, 0]} s={[0.66, 0.66]} px={[128, 128]} draw={(c, W, H) => drawTrefoil(c, W, H)} />)}
      {[1, -1].map((sd) => <CanvasPlane key={"s" + sd} p={[-1.2, 0, sd * (r + 0.02)]} rot={[0, sd > 0 ? 0 : Math.PI, 0]} s={[1.1, 0.4]} px={[220, 80]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.fillStyle = "#f4f1e6"; c.font = "900 62px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("T-5", W / 2, H / 2 + 3); }} />)}
      {noseDecal ? <CanvasPlane p={[L / 2 + r * 1.8 + 0.02, 0, 0]} rot={[0, Math.PI / 2, 0]} s={[0.5, 0.5]} px={[128, 128]} draw={(c, W, H) => drawTrefoil(c, W, H)} /> : null}
    </> : null}
  </group>
);

/* ---------- instruments ---------- */
export const Gauge: React.FC<{ p: V3; r?: number; v: number; rot?: V3; label?: string; red?: number; face?: string }> = ({ p, r = 0.45, v, rot, label = "", red = 0.72, face = "#f4efe0" }) => (
  <group position={p} rotation={rot}>
    <Cyl p={[0, 0, -0.05]} rt={r + 0.08} h={0.1} color="#c9a24a" rot={[Math.PI / 2, 0, 0]} line={2} />
    <CanvasPlane p={[0, 0, 0.012]} s={[r * 2, r * 2]} px={[200, 200]} draw={(c, W, H) => {
      c.clearRect(0, 0, W, H); c.fillStyle = face; c.beginPath(); c.arc(W / 2, H / 2, W / 2 - 4, 0, 7); c.fill(); c.strokeStyle = INK; c.lineWidth = 6; c.stroke();
      const a0 = Math.PI * 0.75, a1 = Math.PI * 2.25; c.strokeStyle = "#e5233a"; c.lineWidth = 14; c.beginPath(); c.arc(W / 2, H / 2, W / 2 - 24, a0 + (a1 - a0) * red, a1); c.stroke();
      c.strokeStyle = INK; c.lineWidth = 4; for (let i = 0; i <= 10; i++) { const a = a0 + (a1 - a0) * i / 10; c.beginPath(); c.moveTo(W / 2 + Math.cos(a) * (W / 2 - 14), H / 2 + Math.sin(a) * (W / 2 - 14)); c.lineTo(W / 2 + Math.cos(a) * (W / 2 - 34), H / 2 + Math.sin(a) * (W / 2 - 34)); c.stroke(); }
      c.fillStyle = INK; c.font = "900 34px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(label, W / 2, H * 0.76);
      const a = a0 + (a1 - a0) * clamp(v); c.strokeStyle = "#c01a2e"; c.lineWidth = 9; c.lineCap = "round"; c.beginPath(); c.moveTo(W / 2, H / 2); c.lineTo(W / 2 + Math.cos(a) * (W / 2 - 30), H / 2 + Math.sin(a) * (W / 2 - 30)); c.stroke(); c.fillStyle = INK; c.beginPath(); c.arc(W / 2, H / 2, 11, 0, 7); c.fill();
    }} />
  </group>
);
export const Thermo: React.FC<{ p: V3; v: number; text: string; rot?: V3; s?: number }> = ({ p, v, text, rot, s = 1 }) => (
  <CanvasPlane p={p} rot={rot} s={[1.1 * s, 2.8 * s]} px={[220, 560]} frame="#c9a24a" draw={(c, W, H) => {
    c.fillStyle = "#f6f0dc"; c.fillRect(0, 0, W, H); const tx = W * 0.34, top = 40, bot = H - 90;
    c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(tx - 18, top, 36, bot - top, 18); c.fill(); c.stroke(); c.beginPath(); c.arc(tx, bot + 30, 40, 0, 7); c.fillStyle = "#e5233a"; c.fill(); c.stroke();
    c.fillStyle = "#e5233a"; const lv = bot - (bot - top - 20) * clamp(v); c.fillRect(tx - 10, lv, 20, bot - lv + 12);
    c.strokeStyle = INK; c.lineWidth = 4; for (let i = 0; i <= 8; i++) { const y = bot - (bot - top - 20) * i / 8; c.beginPath(); c.moveTo(tx + 24, y); c.lineTo(tx + (i % 2 ? 40 : 52), y); c.stroke(); }
    c.save(); c.translate(W * 0.78, H * 0.45); c.rotate(-Math.PI / 2); c.fillStyle = v > 0.8 ? "#e5233a" : INK; c.font = "900 92px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, 0, 0); c.restore();
  }} />
);
export const Valve: React.FC<{ p: V3; r?: number; rot?: V3; spin?: number; color?: string }> = ({ p, r = 0.34, rot, spin = 0, color = "#e5233a" }) => (
  <group position={p} rotation={rot}><group rotation={[0, 0, spin]}><Ring p={[0, 0, 0]} R={r} r={0.045} color={color} ink={0.02} />{[0, 1, 2].map((i) => <Box key={i} p={[0, 0, 0]} rot={[0, 0, i * 1.047]} s={[r * 2, 0.05, 0.05]} color={color} line={1} />)}</group><Cyl p={[0, 0, -0.15]} rt={0.06} h={0.3} rot={[Math.PI / 2, 0, 0]} color="#8c92a8" line={1} /></group>
);
export const ShipBell: React.FC<{ p: V3; swing: number; clap: number }> = ({ p, swing, clap }) => (
  <group position={p}>
    <Box p={[0, 0.12, -0.1]} s={[1.2, 0.16, 0.5]} color="#5a3a22" line={2} />
    <group rotation={[0, 0, swing]}>
      <Cyl p={[0, -0.1, 0]} rt={0.05} h={0.3} color="#2b3350" line={1} />
      <Cyl p={[0, -0.62, 0]} rt={0.2} rb={0.46} h={0.82} color="#f0b23a" />
      <Cyl p={[0, -1.06, 0]} rt={0.5} h={0.09} color="#ffd36a" line={2} />
      <group position={[0, -0.3, 0]} rotation={[0, 0, clap]}><Cyl p={[0, -0.35, 0]} rt={0.025} h={0.7} color="#2b3350" line={1} /><Ball p={[0, -0.75, 0]} r={0.1} color="#8a5a22" ink={0.02} /></group>
    </group>
  </group>
);

/* ---------- sea, sky, clouds ---------- */
export const Sea: React.FC<{ y?: number; t: number; size?: number; a?: string; b?: string }> = ({ y = 0, t, size = 500, a = "#1a86d0", b = "#4cb4ee" }) => {
  const tex = useMemo(() => {
    const c = document.createElement("canvas"); c.width = c.height = 256; const g = c.getContext("2d")!; g.fillStyle = a; g.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 26; i++) { const x = (i * 97) % 256, yy = (i * 61) % 256, w = 30 + (i * 13) % 40; g.strokeStyle = i % 3 ? b : "rgba(255,255,255,.75)"; g.lineWidth = i % 3 ? 5 : 3; g.beginPath(); g.moveTo(x, yy); g.quadraticCurveTo(x + w / 2, yy - 9, x + w, yy); g.stroke(); }
    const t2 = new THREE.CanvasTexture(c); t2.wrapS = t2.wrapT = THREE.RepeatWrapping; t2.repeat.set(size / 9, size / 9); t2.colorSpace = THREE.SRGBColorSpace; t2.anisotropy = 8; return t2;
  }, [a, b, size]);
  tex.offset.set(t * 0.015, t * 0.03);
  return <mesh position={[0, y, 0]} rotation={[-Math.PI / 2, 0, 0]}><planeGeometry args={[size, size]} /><meshBasicMaterial map={tex} /></mesh>;
};
// sea surface seen from BELOW (caustic sheet)
export const SurfaceBelow: React.FC<{ y: number; t: number; size?: number }> = ({ y, t, size = 300 }) => {
  const tex = useMemo(() => {
    const c = document.createElement("canvas"); c.width = c.height = 256; const g = c.getContext("2d")!; g.fillStyle = "#5fc8ee"; g.fillRect(0, 0, 256, 256);
    g.strokeStyle = "rgba(230,255,255,.85)"; g.lineWidth = 5; for (let i = 0; i < 18; i++) { const x = (i * 71) % 256, yy = (i * 113) % 256; g.beginPath(); g.moveTo(x, yy); g.bezierCurveTo(x + 30, yy - 20, x + 50, yy + 26, x + 80, yy + 4); g.stroke(); }
    const t2 = new THREE.CanvasTexture(c); t2.wrapS = t2.wrapT = THREE.RepeatWrapping; t2.repeat.set(size / 14, size / 14); t2.colorSpace = THREE.SRGBColorSpace; return t2;
  }, [size]);
  tex.offset.set(t * 0.02, -t * 0.012);
  return <mesh position={[0, y, 0]} rotation={[Math.PI / 2, 0, 0]}><planeGeometry args={[size, size]} /><meshBasicMaterial map={tex} fog={false} /></mesh>;
};
export const SkyDome: React.FC<{ top: string; mid?: string; bottom: string; stars?: number; r?: number; p?: V3 }> = ({ top, mid, bottom, stars = 0, r = 180, p = [0, 0, 0] }) => {
  const tex = useMemo(() => {
    const c = document.createElement("canvas"); c.width = 1024; c.height = 512; const g = c.getContext("2d")!;
    const gr = g.createLinearGradient(0, 0, 0, 512); gr.addColorStop(0, top); if (mid) gr.addColorStop(0.38, mid); gr.addColorStop(0.5, bottom); gr.addColorStop(1, bottom); g.fillStyle = gr; g.fillRect(0, 0, 1024, 512);
    for (let i = 0; i < stars; i++) { const x = ((i * 7919) % 1000) / 1000 * 1024, y = ((i * 104729) % 1000) / 1000 * 230; g.fillStyle = `rgba(255,255,235,${0.5 + (i % 5) * 0.1})`; g.beginPath(); g.arc(x, y, 0.8 + (i % 3) * 0.7, 0, 7); g.fill(); }
    const t2 = new THREE.CanvasTexture(c); t2.colorSpace = THREE.SRGBColorSpace; return t2;
  }, [top, mid, bottom, stars]);
  return <mesh position={p}><sphereGeometry args={[r, 48, 24]} /><meshBasicMaterial map={tex} side={THREE.BackSide} fog={false} /></mesh>;
};
export const Cloud: React.FC<{ p: V3; s?: number; color?: string }> = ({ p, s = 1, color = "#ffffff" }) => (
  <group position={p} scale={s}>{[[0, 0, 0, 2.2], [2.2, -0.4, 0.3, 1.6], [-2.1, -0.5, 0.2, 1.5], [0.9, 1.1, -0.2, 1.4], [-0.9, 0.9, 0.1, 1.3]].map(([x, y, z, r], i) => <Ball key={i} p={[x, y, z]} r={r} color={color} ink={0.12} />)}</group>
);

/* ---------- mushroom cloud (k: 0..1 growth) ---------- */
export const Mushroom: React.FC<{ p: V3; k: number; t: number; s?: number }> = ({ p, k, t, s = 1 }) => {
  const H = 4 + 24 * k, cap = 2.5 + 7.5 * k, col = (i: number) => ["#ffd08a", "#ff9a4a", "#f4e6d8", "#ffb86a"][i % 4];
  return (<group position={p} scale={s}>
    <Ball p={[0, 0, 0]} r={3 + 9 * k} s={[1, 0.28, 1]} color="#f4efe6" ink={0.2} />
    <Cyl p={[0, H / 2, 0]} rt={1.0 + 1.6 * k} rb={2.4 + 2.2 * k} h={H} color="#ffb070" line={3} />
    {Array.from({ length: 10 }, (_, i) => { const a = i / 10 * Math.PI * 2 + t * 0.15; return <Ball key={i} p={[Math.cos(a) * cap * 0.62, H + Math.sin(i * 2.3) * 0.4 * cap * 0.2, Math.sin(a) * cap * 0.62]} r={cap * 0.46} color={col(i)} ink={0.25} />; })}
    <Ball p={[0, H + cap * 0.42, 0]} r={cap * 0.7} color="#ffe2b0" ink={0.25} />
    {k > 0.35 ? <Ring p={[0, H * 0.58, 0]} R={cap * 0.95 * (k - 0.2)} r={0.5 + 0.6 * k} rot={[Math.PI / 2, 0, 0]} color="#ffffff" ink={0.1} /> : null}
    <Glow p={[0, H, cap * 0.8]} r={cap * 2.4} color="rgba(255,170,80,1)" o={0.55 * (1 - 0.5 * k)} />
  </group>);
};

/* ---------- phone ---------- */
export const PhoneBase: React.FC<{ p: V3; color?: string }> = ({ p, color = "#d2202e" }) => (
  <group position={p}><Box p={[0, 0.11, 0]} s={[0.64, 0.22, 0.5]} color={color} /><Cyl p={[0, 0.24, 0.06]} rt={0.15} h={0.04} color="#f4efe0" line={1} /></group>
);
export const Handset: React.FC<{ p: V3; rot?: V3; color?: string }> = ({ p, rot, color = "#d2202e" }) => (
  <group position={p} rotation={rot}><Box p={[0, 0, 0]} s={[0.12, 0.6, 0.14]} color={color} line={2} /><Box p={[0.06, 0.28, 0]} s={[0.16, 0.16, 0.2]} color={color} line={2} /><Box p={[0.06, -0.28, 0]} s={[0.16, 0.16, 0.2]} color={color} line={2} /></group>
);
void lerp;
